package com.d4.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class KeyAuthActivity extends Activity {

    private EditText    etKey;
    private Button      btnVerify;
    private Button      btnGetKey;
    private ProgressBar progress;
    private TextView    tvError;
    private TextView    tvStatus;

    private SessionManager  session;
    private ExecutorService executor;
    private Handler         handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        session  = new SessionManager(this);
        executor = Executors.newSingleThreadExecutor();
        handler  = new Handler(Looper.getMainLooper());

        // Security checks
        if (SecurityUtils.isCompromised()) {
            showSecurityAlert();
            return;
        }

        // Nếu đã có session hợp lệ → vào thẳng MainActivity
        if (session.hasValidSession()) {
            goMain();
            return;
        }

        buildUI();
    }

    private void buildUI() {
        // ---- Root scroll ----
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#000000"));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#000000"));
        root.setPadding(dp(28), dp(60), dp(28), dp(40));

        // Logo emoji
        TextView tvLogo = new TextView(this);
        tvLogo.setText("🔑");
        tvLogo.setTextSize(56);
        tvLogo.setGravity(Gravity.CENTER);
        tvLogo.setPadding(0, 0, 0, dp(4));
        root.addView(tvLogo);

        // App name
        TextView tvTitle = new TextView(this);
        tvTitle.setText("D4 Game");
        tvTitle.setTextColor(Color.parseColor("#FF8C42"));
        tvTitle.setTextSize(26);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setPadding(0, 0, 0, dp(4));
        root.addView(tvTitle);

        // Subtitle
        TextView tvSub = new TextView(this);
        tvSub.setText("Nhập key để tiếp tục");
        tvSub.setTextColor(Color.parseColor("#888888"));
        tvSub.setTextSize(13);
        tvSub.setGravity(Gravity.CENTER);
        tvSub.setPadding(0, 0, 0, dp(32));
        root.addView(tvSub);

        // Card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(22), dp(20), dp(22));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#1A1A1A"));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        card.setBackground(cardBg);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(cardLp);

        // Label
        TextView tvLabel = new TextView(this);
        tvLabel.setText("LICENSE KEY");
        tvLabel.setTextColor(Color.parseColor("#888888"));
        tvLabel.setTextSize(11);
        tvLabel.setTypeface(Typeface.DEFAULT_BOLD);
        tvLabel.setLetterSpacing(0.12f);
        tvLabel.setPadding(0, 0, 0, dp(8));
        card.addView(tvLabel);

        // EditText nhập key
        etKey = new EditText(this);
        etKey.setHint("XXXX-XXXX-XXXX-XXXX");
        etKey.setHintTextColor(Color.parseColor("#444444"));
        etKey.setTextColor(Color.WHITE);
        etKey.setTextSize(16);
        etKey.setTypeface(Typeface.MONOSPACE);
        etKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS |
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        etKey.setMaxLines(1);
        GradientDrawable etBg = new GradientDrawable();
        etBg.setColor(Color.parseColor("#111111"));
        etBg.setCornerRadius(dp(8));
        etBg.setStroke(dp(1), Color.parseColor("#333333"));
        etKey.setBackground(etBg);
        etKey.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        etLp.setMargins(0, 0, 0, dp(16));
        etKey.setLayoutParams(etLp);
        card.addView(etKey);

        // Nút Verify
        btnVerify = new Button(this);
        btnVerify.setText("Xác thực");
        btnVerify.setTextColor(Color.WHITE);
        btnVerify.setTextSize(15);
        btnVerify.setTypeface(Typeface.DEFAULT_BOLD);
        btnVerify.setAllCaps(false);
        GradientDrawable verifyBg = new GradientDrawable();
        verifyBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        verifyBg.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
        verifyBg.setCornerRadius(dp(10));
        btnVerify.setBackground(verifyBg);
        LinearLayout.LayoutParams verifyLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        btnVerify.setLayoutParams(verifyLp);
        btnVerify.setOnClickListener(v -> onVerifyClicked());
        card.addView(btnVerify);

        root.addView(card);

        // Progress bar
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(dp(36), dp(36));
        progressLp.gravity = Gravity.CENTER_HORIZONTAL;
        progressLp.setMargins(0, 0, 0, dp(4));
        progress.setLayoutParams(progressLp);
        root.addView(progress);

        // Status text
        tvStatus = new TextView(this);
        tvStatus.setTextColor(Color.parseColor("#888888"));
        tvStatus.setTextSize(13);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setPadding(0, 0, 0, dp(4));
        root.addView(tvStatus);

        // Error text
        tvError = new TextView(this);
        tvError.setTextColor(Color.parseColor("#FF4D4D"));
        tvError.setTextSize(13);
        tvError.setGravity(Gravity.CENTER);
        tvError.setVisibility(View.GONE);
        tvError.setPadding(0, 0, 0, dp(12));
        root.addView(tvError);

        // Nút Get Key
        btnGetKey = new Button(this);
        btnGetKey.setText("Lấy Key");
        btnGetKey.setTextColor(Color.parseColor("#FF8C42"));
        btnGetKey.setTextSize(14);
        btnGetKey.setAllCaps(false);
        GradientDrawable getKeyBg = new GradientDrawable();
        getKeyBg.setColor(Color.TRANSPARENT);
        getKeyBg.setCornerRadius(dp(10));
        getKeyBg.setStroke(dp(1), Color.parseColor("#FF4D4D"));
        btnGetKey.setBackground(getKeyBg);
        LinearLayout.LayoutParams getKeyLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        btnGetKey.setLayoutParams(getKeyLp);
        btnGetKey.setOnClickListener(v -> {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(ApiClient.GET_KEY_URL)));
        });
        root.addView(btnGetKey);

        // Footer
        TextView tvFooter = new TextView(this);
        tvFooter.setText("Powered by D4 KeyAuth");
        tvFooter.setTextColor(Color.parseColor("#333333"));
        tvFooter.setTextSize(11);
        tvFooter.setGravity(Gravity.CENTER);
        tvFooter.setPadding(0, dp(32), 0, 0);
        root.addView(tvFooter);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void onVerifyClicked() {
        String key = etKey.getText().toString().trim();
        if (key.isEmpty()) { showError("Vui lòng nhập key"); return; }
        if (key.length() < 8) { showError("Key không hợp lệ"); return; }

        // Security check lại trước khi gửi
        if (SecurityUtils.isCompromised()) { showSecurityAlert(); return; }

        setLoading(true);
        tvError.setVisibility(View.GONE);
        tvStatus.setText("Đang xác thực...");

        String deviceId = session.getDeviceId(this);

        executor.execute(() -> {
            ApiClient.VerifyResult result = ApiClient.verifyKey(key, deviceId);
            handler.post(() -> {
                setLoading(false);
                if (result.success) {
                    session.saveSession(result.token, result.expiresAt);
                    tvStatus.setText("✓ Xác thực thành công!");
                    tvStatus.setTextColor(Color.parseColor("#FF8C42"));
                    btnVerify.postDelayed(this::goMain, 600);
                } else {
                    showError(mapError(result.error));
                    tvStatus.setText("");
                }
            });
        });
    }

    private String mapError(String code) {
        if (code == null) return "❌ Lỗi không xác định";
        switch (code) {
            case "invalid_key":     return "❌ Key không đúng hoặc không tồn tại";
            case "key_expired":     return "⏰ Key đã hết hạn. Liên hệ admin để gia hạn";
            case "key_banned":      return "🚫 Key đã bị khóa";
            case "device_mismatch": return "📱 Key này đã dùng trên thiết bị khác";
            case "network_error":   return "🌐 Không kết nối được server. Kiểm tra mạng";
            default:                return "❌ Lỗi: " + code;
        }
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean on) {
        btnVerify.setEnabled(!on);
        btnGetKey.setEnabled(!on);
        etKey.setEnabled(!on);
        progress.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void showSecurityAlert() {
        new AlertDialog.Builder(this)
            .setTitle("Cảnh báo bảo mật")
            .setMessage("Ứng dụng không thể chạy trên thiết bị đã root, giả lập hoặc có công cụ can thiệp.")
            .setCancelable(false)
            .setPositiveButton("Đóng", (d, w) -> finishAffinity())
            .show();
    }

    private int dp(int val) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(val * density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
