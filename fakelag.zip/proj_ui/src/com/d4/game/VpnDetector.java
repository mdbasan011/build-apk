package com.d4.game;

// Placeholder - khong dung trong version nay
public class VpnDetector {
    public static class DetectResult {
        public boolean vpnDetected    = false;
        public String  localIP        = "";
        public String  detectedIface  = "";
        public int     confidenceScore = 0;
    }
    public static DetectResult fullDetect(android.content.Context ctx) {
        return new DetectResult();
    }
}
