package com.d4.game;

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */

import android.content.Intent;
import android.net.VpnService;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class FakeLagReborn1 extends VpnService implements Runnable {

    public static final String ACTION_FREEZEV2 = "com.fakelag.reborn.FREEZEV2";
    public static final String ACTION_INGAME = "com.fakelag.reborn.INGAME";
    public static final String ACTION_NINJA_V2 = "com.fakelag.reborn.NINJA_V2";
    public static final String ACTION_SET_APP = "com.fakelag.reborn.SET_APP";
    public static final String ACTION_STOP = "com.fakelag.reborn.STOP";
    public static final String ACTION_TELEPORT_V2_EXEC = "com.fakelag.reborn.TELEPORT_V2_EXEC";
    public static final String ACTION_TELEPORT_V2_MARK = "com.fakelag.reborn.TELEPORT_V2_MARK";
    public static final String ACTION_VPN_SWAP = "com.fakelag.reborn.VPN_SWAP";
    public static final String EXTRA_PACKAGE = "PACKAGE";
    public static final String EXTRA_STATE = "EXPLICIT_STATE";

    private static final int VPN_MTU = 1500;
    private static final int VPN_ADDRESS = 0x0A0A0A01; // 10.10.10.1

    public static volatile String currentTunnelIp = "";
    public static final Set<Integer> blockedTcpPorts = Collections.newSetFromMap(new ConcurrentHashMap<>());
    public static volatile long TELEPORT_V2_STEP_MS = 8L;

    private ExecutorService pool;
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean isRunning = false;
    private volatile boolean isFreezeV2 = false;
    private volatile boolean isIngame = false;
    private volatile boolean isNinjaV2 = false;
    private volatile boolean isTeleportV2Hold = false;
    private volatile String targetApp = "";

    private Thread vpnThread;
    private final ConcurrentLinkedDeque<byte[]> teleportBuffer = new ConcurrentLinkedDeque<>();
    private final ConcurrentHashMap<String, DatagramSocket> udpSockets = new ConcurrentHashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        pool = Executors.newCachedThreadPool();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    case ACTION_FREEZEV2:
                        isFreezeV2 = intent.getBooleanExtra(EXTRA_STATE, false);
                        break;
                    case ACTION_INGAME:
                        isIngame = intent.getBooleanExtra(EXTRA_STATE, false);
                        break;
                    case ACTION_NINJA_V2:
                        isNinjaV2 = intent.getBooleanExtra(EXTRA_STATE, false);
                        break;
                    case ACTION_SET_APP:
                        targetApp = intent.getStringExtra(EXTRA_PACKAGE);
                        if (targetApp != null && !targetApp.isEmpty()) {
                            startVpn();
                        }
                        break;
                    case ACTION_STOP:
                        stopVpn();
                        break;
                    case ACTION_TELEPORT_V2_MARK:
                        isTeleportV2Hold = true;
                        break;
                    case ACTION_TELEPORT_V2_EXEC:
                        isTeleportV2Hold = false;
                        flushTeleportBuffer();
                        break;
                }
            }
        }
        return START_STICKY;
    }

    private void startVpn() {
        if (isRunning) return;

        try {
            Builder builder = new Builder();
            builder.setSession("RAIKU // THUNDER_PAIN");
            builder.addAddress("10.10.10.1", 32);
            builder.addRoute("0.0.0.0", 0);
            builder.setMtu(VPN_MTU);
            builder.setBlocking(true);

            vpnInterface = builder.establish();
            if (vpnInterface != null) {
                isRunning = true;
                vpnThread = new Thread(this);
                vpnThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopVpn() {
        isRunning = false;
        if (vpnThread != null) {
            vpnThread.interrupt();
        }
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (Exception e) {
                // Ignore
            }
            vpnInterface = null;
        }

        // Close all UDP sockets
        for (DatagramSocket sock : udpSockets.values()) {
            try {
                sock.close();
            } catch (Exception e) {
                // Ignore
            }
        }
        udpSockets.clear();
    }

    @Override
    public void run() {
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
        byte[] packet = new byte[VPN_MTU];

        while (isRunning) {
            try {
                int length = in.read(packet);
                if (length > 0) {
                    byte[] data = Arrays.copyOf(packet, length);

                    // Freeze mode: drop all packets
                    if (isFreezeV2) {
                        continue;
                    }

                    // Ninja mode: modify packet
                    if (isNinjaV2) {
                        data = modifyPacket(data);
                    }

                    // Teleport mode: buffer and replay
                    if (isTeleportV2Hold) {
                        if (teleportBuffer.size() < 1000) {
                            teleportBuffer.add(data);
                        }
                        continue;
                    }

                    out.write(data);
                }
            } catch (Exception e) {
                if (isRunning) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    private byte[] modifyPacket(byte[] packet) {
        // Simple modification for ninja effect
        if (packet.length > 20) {
            packet[8] = (byte) (packet[8] - 1); // Decrease TTL
        }
        return packet;
    }

    private void flushTeleportBuffer() {
        if (vpnInterface == null) return;

        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
						while (!teleportBuffer.isEmpty()) {
							byte[] data = teleportBuffer.poll();
							if (data != null) {
								out.write(data);
								Thread.sleep(TELEPORT_V2_STEP_MS);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}).start();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        if (pool != null) {
            pool.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * Helper class for connection key
     */
    static class ConnKey {
        final int src;
        final int dst;
        final int ip;

        ConnKey(int src, int dst, int ip) {
            this.src = src;
            this.dst = dst;
            this.ip = ip;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ConnKey connKey = (ConnKey) o;
            return src == connKey.src && dst == connKey.dst && ip == connKey.ip;
        }

        @Override
        public int hashCode() {
            return src * 31 * 31 + dst * 31 + ip;
        }
    }

    /**
     * Helper class for packet
     */
    static class Packet {
        byte[] data;
        int dataLen;
        int dstIp;
        short dstPort;
        int proto;
        short srcPort;

        Packet(byte[] buffer, int length) {
            this.data = Arrays.copyOf(buffer, length);
            this.dataLen = length;
        }

        boolean isMovement() {
            // Simple movement detection based on packet size
            return dataLen > 60 && dataLen < 200;
        }
    }
}

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */
