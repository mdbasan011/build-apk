package com.d4.game;

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FakeLagReborn2 extends Service {

    private static final String TAG = "FakeLagReborn2";

    // Button states
    public static boolean stateFreezeV2 = false;
    public static boolean stateIngame = false;
    public static boolean stateNinjaV2 = false;
    public static boolean stateVpnSwap = false;
    public static boolean stateTeleportV2 = false;

    // Button locks
    public static boolean lockedFreezeV2 = false;
    public static boolean lockedNinjaV2 = false;
    public static boolean lockedVpnSwap = false;
    public static boolean lockedTeleportV2 = false;
    public static boolean lockedLogin = false;

    // Button positions
    public static int posXFreezeV2 = 20;
    public static int posYFreezeV2 = 900;
    public static int posXNinjaV2 = 20;
    public static int posYNinjaV2 = 750;
    public static int posXVpnSwap = 20;
    public static int posYVpnSwap = 300;
    public static int posXTeleportV2 = 20;
    public static int posYTeleportV2 = 1200;
    public static int posXLogin = 20;
    public static int posYLogin = 150;

    // Button sizes
    public static int szFreezeV2 = 70;
    public static int szNinjaV2 = 70;
    public static int szVpnSwap = 70;
    public static int szTeleportV2 = 70;
    public static int szLogin = 70;
    public static int btnSizeDp = 70;

    private WindowManager windowManager;
    private TextView btnFreezeV2;
    private TextView btnNinjaV2;
    private TextView btnVpnSwap;
    private TextView btnTeleportV2;
    private TextView btnLogin;

    private Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createFloatingButtons();
        startNotification();
    }

    private void createFloatingButtons() {
        btnFreezeV2 = createButton("FREEZE", posXFreezeV2, posYFreezeV2, szFreezeV2);
        btnNinjaV2 = createButton("NINJA", posXNinjaV2, posYNinjaV2, szNinjaV2);
        btnVpnSwap = createButton("VPN", posXVpnSwap, posYVpnSwap, szVpnSwap);
        btnTeleportV2 = createButton("TELEPORT", posXTeleportV2, posYTeleportV2, szTeleportV2);
        btnLogin = createButton("LOGIN", posXLogin, posYLogin, szLogin);
    }

    private TextView createButton(String text, int x, int y, int size) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundColor(Color.parseColor("#DD000000"));
        button.setPadding(10, 10, 10, 10);

        // Style
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(8);
        }

        // Layout params
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            dpToPx(size),
            dpToPx(size),
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
			WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
			WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = x;
        params.y = y;

        // Touch listener for dragging
        button.setOnTouchListener(new DragListener(button, params, text));

        windowManager.addView(button, params);
        return button;
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void startNotification() {
        // Start foreground service for Android O+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(1, new android.app.Notification.Builder(this, "nff_floating")
							.setContentTitle("RAIKU // THUNDER_PAIN")
							.setContentText("Floating menu active")
							.setSmallIcon(android.R.drawable.ic_menu_edit)
							.build());
        }
    }

    private void updateButtonState(TextView btn, boolean active, String activeColor, String inactiveColor) {
        if (active) {
            btn.setBackgroundColor(Color.parseColor(activeColor));
        } else {
            btn.setBackgroundColor(Color.parseColor(inactiveColor));
        }
    }

    public void updateAllButtons() {
        updateButtonState(btnFreezeV2, stateFreezeV2, "#FF3366", "#DD000000");
        updateButtonState(btnNinjaV2, stateNinjaV2, "#FF3366", "#DD000000");
        updateButtonState(btnVpnSwap, stateVpnSwap, "#FF3366", "#DD000000");
        updateButtonState(btnTeleportV2, stateTeleportV2, "#FF3366", "#DD000000");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            switch (action) {
                case "com.fakelag.reborn.SET_BTN_VISIBLE":
                    // Handle visibility
                    break;
                case "com.fakelag.reborn.SET_BTN_LOCK":
                    // Handle lock
                    break;
                case "com.fakelag.reborn.MOVE_BTN":
                    // Handle move
                    break;
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (btnFreezeV2 != null) windowManager.removeView(btnFreezeV2);
        if (btnNinjaV2 != null) windowManager.removeView(btnNinjaV2);
        if (btnVpnSwap != null) windowManager.removeView(btnVpnSwap);
        if (btnTeleportV2 != null) windowManager.removeView(btnTeleportV2);
        if (btnLogin != null) windowManager.removeView(btnLogin);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // Drag touch listener
    private class DragListener implements View.OnTouchListener {
        private TextView view;
        private WindowManager.LayoutParams params;
        private String label;
        private int initialX, initialY;
        private float touchX, touchY;
        private boolean isDragging = false;
        private static final int LONG_PRESS_TIME = 500;
        private Handler handler = new Handler();
        private Runnable longPressRunnable;

        DragListener(TextView view, WindowManager.LayoutParams params, String label) {
            this.view = view;
            this.params = params;
            this.label = label;

            longPressRunnable = new Runnable() {
                @Override
                public void run() {
                    // Long press action - toggle lock
                    toggleLock();
                }
            };
        }

        private void toggleLock() {
            switch (label) {
                case "FREEZE":
                    lockedFreezeV2 = !lockedFreezeV2;
                    break;
                case "NINJA":
                    lockedNinjaV2 = !lockedNinjaV2;
                    break;
                case "VPN":
                    lockedVpnSwap = !lockedVpnSwap;
                    break;
                case "TELEPORT":
                    lockedTeleportV2 = !lockedTeleportV2;
                    break;
                case "LOGIN":
                    lockedLogin = !lockedLogin;
                    break;
            }
            view.setAlpha(lockedFreezeV2 || lockedNinjaV2 || lockedVpnSwap || lockedTeleportV2 || lockedLogin ? 0.5f : 1.0f);
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    isDragging = false;
                    handler.postDelayed(longPressRunnable, LONG_PRESS_TIME);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float deltaX = event.getRawX() - touchX;
                    float deltaY = event.getRawY() - touchY;
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isDragging = true;
                        handler.removeCallbacks(longPressRunnable);
                    }
                    if (isDragging) {
                        params.x = initialX + (int) deltaX;
                        params.y = initialY + (int) deltaY;
                        windowManager.updateViewLayout(view, params);

                        // Save position
                        savePosition(params.x, params.y);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    handler.removeCallbacks(longPressRunnable);
                    if (!isDragging) {
                        // Click action - toggle state
                        toggleState();
                    }
                    return true;
            }
            return false;
        }

        private void toggleState() {
            switch (label) {
                case "FREEZE":
                    stateFreezeV2 = !stateFreezeV2;
                    updateButtonState(view, stateFreezeV2, "#FF3366", "#DD000000");
                    break;
                case "NINJA":
                    stateNinjaV2 = !stateNinjaV2;
                    updateButtonState(view, stateNinjaV2, "#FF3366", "#DD000000");
                    break;
                case "VPN":
                    stateVpnSwap = !stateVpnSwap;
                    updateButtonState(view, stateVpnSwap, "#FF3366", "#DD000000");
                    break;
                case "TELEPORT":
                    stateTeleportV2 = !stateTeleportV2;
                    updateButtonState(view, stateTeleportV2, "#FF3366", "#DD000000");
                    break;
            }
        }

        private void savePosition(int x, int y) {
            switch (label) {
                case "FREEZE":
                    posXFreezeV2 = x;
                    posYFreezeV2 = y;
                    break;
                case "NINJA":
                    posXNinjaV2 = x;
                    posYNinjaV2 = y;
                    break;
                case "VPN":
                    posXVpnSwap = x;
                    posYVpnSwap = y;
                    break;
                case "TELEPORT":
                    posXTeleportV2 = x;
                    posYTeleportV2 = y;
                    break;
                case "LOGIN":
                    posXLogin = x;
                    posYLogin = y;
                    break;
            }
        }
    }
}

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */
