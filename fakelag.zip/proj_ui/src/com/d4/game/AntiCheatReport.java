package com.d4.game;

// Placeholder - khong dung trong version nay
public class AntiCheatReport {
    public boolean vpnDetected = false;
    public String  localIP     = "";
}
