package com.d4.game;

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.Thread;

public class FakeLagReborn3 {
    private static final String LOG_FILE = "NinjaFFCrash.log";
    private static Context appCtx;
    private static volatile boolean installed;

    public static class CrashHandler implements Thread.UncaughtExceptionHandler {
        private final Thread.UncaughtExceptionHandler defaultHandler;

        public CrashHandler(Thread.UncaughtExceptionHandler handler) {
            this.defaultHandler = handler;
        }

        @Override
        public void uncaughtException(Thread thread, Throwable th) {
            if (defaultHandler != null) {
                defaultHandler.uncaughtException(thread, th);
            }
            FakeLagReborn3.writeCrashLog(thread, th);
        }
    }

    static {
        installed = false;
        appCtx = null;
    }

    public static synchronized void install(Context context) {
        if (installed) return;
        appCtx = context.getApplicationContext();
        installed = true;
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(Thread.getDefaultUncaughtExceptionHandler()));
    }

    private static File getLogFile() {
        if (appCtx != null) {
            return new File(appCtx.getFilesDir(), LOG_FILE);
        }
        return new File(LOG_FILE);
    }

    private static void writeCrashLog(Thread thread, Throwable th) {
        File logFile = getLogFile();
        try {
            FileWriter fw = new FileWriter(logFile, true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println("=== Crash Report ===");
            pw.println("Thread: " + thread.getName());
            pw.println("Time: " + System.currentTimeMillis());
            pw.println("Exception: " + th.toString());
            for (StackTraceElement element : th.getStackTrace()) {
                pw.println("    at " + element.toString());
            }
            pw.println("====================");
            pw.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */
