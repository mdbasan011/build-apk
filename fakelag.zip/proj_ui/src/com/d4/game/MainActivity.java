package com.d4.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_VPN = 1001;
    private static final int REQ_OVERLAY = 1002;
    private static final int REQ_NOTIFICATION = 1003;
    private static final String PKG_FF = "com.dts.freefireth";

    // String literal cho MyVpnService1
    private static final String ACTION_STATE = "com.d4.game.VPN_STATE";
    private static final String EXTRA_RUNNING = "running";
    private static final String ACTION_START = "com.d4.game.START";
    private static final String ACTION_STOP = "com.d4.game.STOP";

    // UI Components
    private Button btnEngine;
    private Button btnFFNormal;
    private Button btnFFMax;
    private Button btnRetry;
    private Button btnStopEngine;
    private Button btnEnglish;
    private Button btnVietnamese;
    private Button btnVpnOff;
    private Button btnMenu;
    private TextView tvApp;
    private TextView tvStatus;
    private TextView tvStats;
    private TextView tvServerStatus;
    private TextView tvHD;
    private TextView tvStep;
    private TextView tvTitle;

    // Custom Checkboxes cho Floating Buttons (Ẩn/Hiện)
    private CustomCheckBox chkFloatingVPN;
    private CustomCheckBox chkFloatingGhost;
    private CustomCheckBox chkFloatingFreeze;
    private CustomCheckBox chkFloatingTeleportV1;
    private CustomCheckBox chkFloatingTeleportV2;

    // Checkboxes cho Permissions
    private CustomCheckBox chkPermVPN;
    private CustomCheckBox chkPermFloating;
    private CustomCheckBox chkPermNotification;

    // SeekBars (các thông số delay)
    private SeekBar sbVpn;
    private SeekBar sbGhost;
    private SeekBar sbFreeze;
    private SeekBar sbTele;
    private SeekBar sbFreeze2;
    private SeekBar sbTele2;

    private TextView tvVpnVal, tvGhostVal, tvFreezeVal, tvTeleVal, tvFreeze2Val, tvTele2Val;

    private String selPkg = null;
    private boolean engOn = false;
    private boolean waiting = false;
    private boolean isVietnamese = false;
    private boolean vpnGranted = false;
    private boolean overlayGranted = false;
    private boolean notifGranted = false;

    private boolean isFFNormalSelected = true;
    private boolean isFFMaxSelected = false;

    private List<ApplicationInfo> appList = new ArrayList<>();
    private String[] appNames;
    private boolean loaded = false;

    private BroadcastReceiver statsRcv;

    private WindowManager windowManager;
    private TextView overlayTextView;
    private boolean isOverlayShowing = false;

    public interface OnCheckChangeListener {
        void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked);
    }

    public class CustomCheckBox extends View {
        private boolean isChecked = false;
        private Paint bgPaint;
        private Paint borderPaint;
        private Paint checkPaint;
        private RectF rect;
        private int size = 40;
        private OnCheckChangeListener listener;

        public CustomCheckBox(Context context) {
            super(context);
            init();
        }

        private void init() {
            bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgPaint.setStyle(Paint.Style.FILL);

            borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(dp(2.5f));

            checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(3.5f));
            checkPaint.setColor(Color.WHITE);

            rect = new RectF();
            setChecked(false);

            setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						toggle();
						if (listener != null) {
							listener.onCheckedChanged(CustomCheckBox.this, isChecked);
						}
					}
				});
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int px = dp(size);
            setMeasuredDimension(px, px);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            int padding = dp(4);
            rect.set(padding, padding, w - padding, h - padding);

            if (isChecked) {
                // Gradient checked premium
                bgPaint.setShader(new android.graphics.LinearGradient(0, 0, w, h, Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42"), android.graphics.Shader.TileMode.CLAMP));
                canvas.drawRoundRect(rect, dp(12), dp(12), bgPaint);
                drawCheck(canvas);
            } else {
                borderPaint.setColor(Color.parseColor("#2A2A2A"));
                canvas.drawRoundRect(rect, dp(12), dp(12), borderPaint);
            }
        }

        private void drawCheck(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            int padding = dp(9);
            float startX = padding + dp(1);
            float startY = h / 2 + dp(1);
            float midX = w / 2 - dp(1);
            float midY = h - padding - dp(1);
            float endX = w - padding - dp(1);
            float endY = padding + dp(2);
            checkPaint.setColor(Color.WHITE);
            canvas.drawLine(startX, startY, midX, midY, checkPaint);
            canvas.drawLine(midX, midY, endX, endY, checkPaint);
        }

        public void setChecked(boolean checked) {
            this.isChecked = checked;
            invalidate();
        }

        public boolean isChecked() {
            return isChecked;
        }

        public void toggle() {
            setChecked(!isChecked);
        }

        public void setOnCheckChangeListener(OnCheckChangeListener l) {
            this.listener = l;
        }
    }

    private LinearLayout createCheckboxRow(String label, CustomCheckBox checkBox) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(24), dp(14), dp(24), dp(14));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#FFFFFF"));
        lbl.setTextSize(15);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lblParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lbl.setLayoutParams(lblParams);

        row.addView(lbl);
        row.addView(checkBox);

        return row;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        // ---- KEY AUTH: Kiểm tra session ----
        SessionManager _session = new SessionManager(this);
        if (!_session.hasValidSession()) {
            startActivity(new Intent(this, KeyAuthActivity.class));
            finish();
            return;
        }
        // ---- END KEY AUTH ----

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        checkPermissions();

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#000000"));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#000000"));
        root.setPadding(dp(24), dp(48), dp(24), dp(40));

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.END);
        header.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        btnVpnOff = createSimpleButton("VPN OFF", "#FF8C42", "#1E1E1E", "#FF8C42", dp(110), dp(42));
        btnVpnOff.setTextSize(12);
        btnMenu = createSimpleButton("...", "#FFFFFF20", "#1E1E1E", "#FFFFFF", dp(44), dp(44));
        btnMenu.setTextSize(22);
        btnMenu.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(btnVpnOff);
        header.addView(btnMenu);
        root.addView(header);

        // Logo
        FrameLayout logoCard = new FrameLayout(this);
        logoCard.setLayoutParams(new LinearLayout.LayoutParams(dp(120), dp(120)));
        GradientDrawable logoBg = new GradientDrawable();
        logoBg.setColor(Color.parseColor("#FF4D4D20"));
        logoBg.setCornerRadius(dp(60));
        logoBg.setStroke(dp(3), Color.parseColor("#FF4D4D"));
        logoCard.setBackground(logoBg);

        ImageView imgLogo = new ImageView(this);
        imgLogo.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        try {
            imgLogo.setImageResource(R.drawable.ic_launcher);
        } catch (Exception e) {
            imgLogo.setBackgroundColor(Color.parseColor("#FF4D4D"));
        }
        imgLogo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logoCard.addView(imgLogo);
        root.addView(logoCard);

        // Title
        tvTitle = new TextView(this);
        tvTitle.setText("Psycho Developer // Fox Ping Lag");
        tvTitle.setTextSize(42);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setTextColor(Color.parseColor("#FF4D4D"));
        tvTitle.setGravity(Gravity.CENTER);
        tvTitle.setShadowLayer(18f, 0f, 0f, Color.parseColor("#FF4D4D"));
        tvTitle.setLetterSpacing(0.06f);
        addTo(root, tvTitle, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(16), 0, 0);

        // Language Buttons
        LinearLayout langRow = new LinearLayout(this);
        langRow.setOrientation(LinearLayout.HORIZONTAL);
        langRow.setGravity(Gravity.CENTER);
        langRow.setPadding(0, dp(8), 0, dp(8));
        btnEnglish = createSelectableButton("ENGLISH", true);
        btnVietnamese = createSelectableButton("TIẾNG VIỆT", false);
        langRow.addView(btnEnglish);
        langRow.addView(btnVietnamese);
        addTo(root, langRow, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, 0);

        // FF Buttons
        LinearLayout ffRow = new LinearLayout(this);
        ffRow.setOrientation(LinearLayout.HORIZONTAL);
        ffRow.setGravity(Gravity.CENTER);
        ffRow.setPadding(0, dp(4), 0, dp(16));
        btnFFNormal = createSelectableButton("FF NORMAL", true);
        btnFFMax = createSelectableButton("FF MAX", false);
        btnRetry = createSelectableButton("RETRY", false);
        ffRow.addView(btnFFNormal);
        ffRow.addView(btnFFMax);
        ffRow.addView(btnRetry);
        addTo(root, ffRow, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, 0);

        // Status Container - Glassmorphism
        LinearLayout statusContainer = new LinearLayout(this);
        statusContainer.setOrientation(LinearLayout.VERTICAL);
        statusContainer.setPadding(dp(24), dp(20), dp(24), dp(20));
        GradientDrawable statusBg = new GradientDrawable();
        statusBg.setColor(Color.parseColor("#111111CC"));
        statusBg.setCornerRadius(dp(32));
        statusBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        statusContainer.setBackground(statusBg);

        tvStatus = new TextView(this);
        tvStatus.setText("VPN STATUS: OFF");
        tvStatus.setTextSize(18);
        tvStatus.setTextColor(Color.parseColor("#FF4D4D"));
        tvStatus.setTypeface(Typeface.DEFAULT_BOLD);
        tvStatus.setGravity(Gravity.CENTER);
        statusContainer.addView(tvStatus);

        tvStats = new TextView(this);
        tvStats.setText("OFF | LOSS: 0% | PING: 0ms");
        tvStats.setTextSize(14);
        tvStats.setTextColor(Color.parseColor("#CCCCCC"));
        tvStats.setTypeface(Typeface.MONOSPACE);
        tvStats.setGravity(Gravity.CENTER);
        statusContainer.addView(tvStats);

        tvServerStatus = new TextView(this);
        tvServerStatus.setText("Server: OK ✓");
        tvServerStatus.setTextSize(14);
        tvServerStatus.setTextColor(Color.parseColor("#CCCCCC"));
        tvServerStatus.setTypeface(Typeface.MONOSPACE);
        tvServerStatus.setGravity(Gravity.CENTER);
        statusContainer.addView(tvServerStatus);

        tvApp = new TextView(this);
        tvApp.setText("No app selected");
        tvApp.setTextSize(14);
        tvApp.setTextColor(Color.parseColor("#CCCCCC"));
        tvApp.setTypeface(Typeface.MONOSPACE);
        tvApp.setGravity(Gravity.CENTER);
        statusContainer.addView(tvApp);

        addTo(root, statusContainer, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(12), 0, dp(32));

        // ==================== FLOATING BUTTONS SECTION (ẨN/HIỆN) ====================
        TextView tvFloatingTitle = new TextView(this);
        tvFloatingTitle.setText("⚡ ẨN/HIỆN NÚT NỔI");
        tvFloatingTitle.setTextSize(18);
        tvFloatingTitle.setTextColor(Color.parseColor("#FF8C42"));
        tvFloatingTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvFloatingTitle.setLetterSpacing(1f);
        tvFloatingTitle.setPadding(0, dp(8), 0, dp(8));
        addTo(root, tvFloatingTitle, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, 0);

        LinearLayout floatingButtonsContainer = new LinearLayout(this);
        floatingButtonsContainer.setOrientation(LinearLayout.VERTICAL);
        floatingButtonsContainer.setPadding(dp(24), dp(12), dp(24), dp(12));
        GradientDrawable fbBg = new GradientDrawable();
        fbBg.setColor(Color.parseColor("#111111CC"));
        fbBg.setCornerRadius(dp(32));
        fbBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        floatingButtonsContainer.setBackground(fbBg);

        chkFloatingVPN = new CustomCheckBox(this);
        chkFloatingGhost = new CustomCheckBox(this);
        chkFloatingFreeze = new CustomCheckBox(this);
        chkFloatingTeleportV1 = new CustomCheckBox(this);
        chkFloatingTeleportV2 = new CustomCheckBox(this);

        floatingButtonsContainer.addView(createCheckboxRow("VPN", chkFloatingVPN));
        floatingButtonsContainer.addView(createCheckboxRow("GHOST", chkFloatingGhost));
        floatingButtonsContainer.addView(createCheckboxRow("FREEZE", chkFloatingFreeze));
        floatingButtonsContainer.addView(createCheckboxRow("TELEPORT V1 (TeleKill)", chkFloatingTeleportV1));
        floatingButtonsContainer.addView(createCheckboxRow("TELEPORT V2", chkFloatingTeleportV2));

        addTo(root, floatingButtonsContainer, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, dp(32));

        // ==================== BUTTON SIZE SECTION (KÍCH THƯỚC TỪNG NÚT) ====================
        TextView tvSizeTitle = new TextView(this);
        tvSizeTitle.setText("📏 KÍCH THƯỚC TỪNG NÚT NỔI (px)");
        tvSizeTitle.setTextSize(18);
        tvSizeTitle.setTextColor(Color.parseColor("#FF8C42"));
        tvSizeTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvSizeTitle.setLetterSpacing(1f);
        tvSizeTitle.setPadding(0, dp(8), 0, dp(8));
        addTo(root, tvSizeTitle, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, 0);

        addButtonSizeControl(root, "VPN", 50, 200, 130, "vpn");
        addButtonSizeControl(root, "GHOST", 50, 200, 130, "ghost");
        addButtonSizeControl(root, "FREEZE", 50, 200, 130, "freeze");
        addButtonSizeControl(root, "TELEPORT V1", 50, 200, 130, "teleport");
        addButtonSizeControl(root, "TELEPORT V2", 50, 200, 130, "teleportv2");

        // ==================== PERMISSIONS SECTION ====================
        TextView tvPermTitle = new TextView(this);
        tvPermTitle.setText("🔐 PERMISSIONS");
        tvPermTitle.setTextSize(18);
        tvPermTitle.setTextColor(Color.parseColor("#FF8C42"));
        tvPermTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvPermTitle.setLetterSpacing(1f);
        tvPermTitle.setPadding(0, dp(8), 0, dp(8));
        addTo(root, tvPermTitle, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, 0);

        LinearLayout permissionsContainer = new LinearLayout(this);
        permissionsContainer.setOrientation(LinearLayout.VERTICAL);
        permissionsContainer.setPadding(dp(24), dp(12), dp(24), dp(12));
        GradientDrawable permBg = new GradientDrawable();
        permBg.setColor(Color.parseColor("#111111CC"));
        permBg.setCornerRadius(dp(32));
        permBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        permissionsContainer.setBackground(permBg);

        chkPermVPN = new CustomCheckBox(this);
        chkPermFloating = new CustomCheckBox(this);
        chkPermNotification = new CustomCheckBox(this);

        permissionsContainer.addView(createCheckboxRow("VPN Permission", chkPermVPN));
        permissionsContainer.addView(createCheckboxRow("Floating Window", chkPermFloating));
        permissionsContainer.addView(createCheckboxRow("Notification", chkPermNotification));

        addTo(root, permissionsContainer, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, dp(32));

        updatePermissionCheckboxes();

        // SeekBars Section
        addSeekBarGroup(root, "VPN", 0, 100, 50);
        addSeekBarGroup(root, "GHOST", 0, 100, 30);
        addSeekBarGroup(root, "FREEZE", 0, 100, 20);
        addSeekBarGroup(root, "TELE", 0, 100, 40);
        addSeekBarGroup(root, "Freeze2", 0, 100, 25);
        addSeekBarGroup(root, "Tele2", 0, 100, 35);

        // Buttons
        btnStopEngine = createStopButton("■ STOP ENGINE", "#FF4D4D", "#1A1A1A", "#FF4D4D");
        addTo(root, btnStopEngine, LinearLayout.LayoutParams.MATCH_PARENT, dp(60), 0, dp(24), 0, dp(16));

        btnEngine = createSimpleButton("START ENGINE", "#FF4D4D", "#FF4D4D", "#FFFFFF", LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        btnEngine.setTextSize(18);
        addTo(root, btnEngine, LinearLayout.LayoutParams.MATCH_PARENT, dp(60), 0, 0, 0, dp(24));

        // Instructions
        tvHD = new TextView(this);
        tvHD.setText("INSTRUCTIONS:");
        tvHD.setTextSize(12);
        tvHD.setTextColor(Color.parseColor("#B3B3B3"));
        tvHD.setTypeface(Typeface.DEFAULT_BOLD);
        addTo(root, tvHD, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(20), 0, dp(6));

        tvStep = new TextView(this);
        tvStep.setTextSize(12);
        tvStep.setTextColor(Color.parseColor("#AAAAAA"));
        tvStep.setTypeface(Typeface.MONOSPACE);
        tvStep.setLineSpacing(dp(8), 1f);
        tvStep.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable stepBg = new GradientDrawable();
        stepBg.setColor(Color.parseColor("#0A0A0A"));
        stepBg.setCornerRadius(dp(20));
        stepBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        tvStep.setBackground(stepBg);
        addTo(root, tvStep, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(20));

        updateLanguage();
        updateGameButtonsStyle();

        scroll.addView(root);
        setContentView(scroll);

        // ========== EVENT HANDLERS ========== (giữ nguyên toàn bộ, không sửa)
        btnFFNormal.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					isFFNormalSelected = true;
					isFFMaxSelected = false;
					updateGameButtonsStyle();
					selectGame(PKG_FF, "Free Fire Normal");
				}
			});

        btnFFMax.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					isFFNormalSelected = false;
					isFFMaxSelected = true;
					updateGameButtonsStyle();
					selectGame(PKG_FF, "Free Fire MAX");
				}
			});

        btnRetry.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					updateGameButtonsStyle();
					if (engOn) stopEngine();
					startEngine();
				}
			});

        btnEnglish.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					isVietnamese = false;
					updateLanguage();
					updateLangButtonsStyle();
					toast("Language switched to English");
				}
			});

        btnVietnamese.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					isVietnamese = true;
					updateLanguage();
					updateLangButtonsStyle();
					toast("Đã chuyển sang Tiếng Việt");
				}
			});

        btnVpnOff.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (engOn) stopEngine();
					else toast("VPN is already OFF");
				}
			});

        btnMenu.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					toast("Menu");
				}
			});

        btnStopEngine.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopEngine();
				}
			});

        btnEngine.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (waiting) return;
					if (!engOn) {
						if (selPkg == null) {
							toast("Select game first!");
							return;
						}
						checkOverlay();
					} else {
						stopEngine();
					}
				}
			});

        // Floating buttons checkboxes - Ẩn/hiện nút nổi
        chkFloatingVPN.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					sendFloatingButtonVisibility("VPN", !isChecked);
				}
			});

        chkFloatingGhost.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					sendFloatingButtonVisibility("GHOST", !isChecked);
				}
			});

        chkFloatingFreeze.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					sendFloatingButtonVisibility("FREEZE", !isChecked);
				}
			});

        chkFloatingTeleportV1.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					sendFloatingButtonVisibility("TELEPORT", !isChecked);
				}
			});

        chkFloatingTeleportV2.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					sendFloatingButtonVisibility("TELEPORTV2", !isChecked);
				}
			});

        chkPermVPN.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					if (!isChecked) checkVpnPermission();
				}
			});

        chkPermFloating.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					if (!isChecked) checkOverlayPermission();
				}
			});

        chkPermNotification.setOnCheckChangeListener(new OnCheckChangeListener() {
				@Override
				public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
					if (!isChecked) checkNotificationPermission();
				}
			});

        loadApps();
        regStats();
    }

    private void addButtonSizeControl(LinearLayout parent, String label, int min, int max, int defaultVal, String buttonType) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.HORIZONTAL);
        group.setGravity(Gravity.CENTER_VERTICAL);
        group.setPadding(0, dp(8), 0, dp(8));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#FF8C42"));
        lbl.setTextSize(14);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        lbl.setWidth(dp(100));

        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(defaultVal - min);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView val = new TextView(this);
        val.setText(String.valueOf(defaultVal) + "px");
        val.setTextColor(Color.parseColor("#FF8C42"));
        val.setTextSize(14);
        val.setTypeface(Typeface.MONOSPACE);
        val.setWidth(dp(60));
        val.setGravity(Gravity.END);

        final int minVal = min;
        final TextView textVal = val;
        final String btnType = buttonType;

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int value = progress + minVal;
					textVal.setText(value + "px");
					Intent intent = new Intent("UPDATE_BUTTON_SIZE");
					intent.putExtra("button_type", btnType);
					intent.putExtra("size", value);
					sendBroadcast(intent);
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        group.addView(lbl);
        group.addView(sb);
        group.addView(val);
        parent.addView(group);
    }

    private Button createSelectableButton(String text, boolean isSelected) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(isSelected ? Color.WHITE : Color.parseColor("#FF4D4D"));
        btn.setTextSize(14);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setAllCaps(false);
        GradientDrawable gd = new GradientDrawable();
        if (isSelected) {
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            gd.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
            gd.setStroke(0, Color.TRANSPARENT);
        } else {
            gd.setColor(Color.TRANSPARENT);
            gd.setStroke(dp(2), Color.parseColor("#FF4D4D"));
        }
        gd.setCornerRadius(dp(40));
        btn.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48));
        lp.setMargins(dp(6), 0, dp(6), 0);
        btn.setLayoutParams(lp);
        btn.setPadding(dp(24), dp(10), dp(24), dp(10));
        return btn;
    }

    private void updateGameButtonsStyle() {
        GradientDrawable gdNormal = (GradientDrawable) btnFFNormal.getBackground();
        GradientDrawable gdMax = (GradientDrawable) btnFFMax.getBackground();
        GradientDrawable gdRetry = (GradientDrawable) btnRetry.getBackground();

        if (isFFNormalSelected) {
            if (gdNormal != null) {
                gdNormal.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                gdNormal.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
                gdNormal.setStroke(0, Color.TRANSPARENT);
                btnFFNormal.setTextColor(Color.WHITE);
            }
            if (gdMax != null) {
                gdMax.setColor(Color.TRANSPARENT);
                gdMax.setStroke(dp(2), Color.parseColor("#FF4D4D"));
                btnFFMax.setTextColor(Color.parseColor("#FF4D4D"));
            }
        } else if (isFFMaxSelected) {
            if (gdNormal != null) {
                gdNormal.setColor(Color.TRANSPARENT);
                gdNormal.setStroke(dp(2), Color.parseColor("#FF4D4D"));
                btnFFNormal.setTextColor(Color.parseColor("#FF4D4D"));
            }
            if (gdMax != null) {
                gdMax.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                gdMax.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
                gdMax.setStroke(0, Color.TRANSPARENT);
                btnFFMax.setTextColor(Color.WHITE);
            }
        }
        if (gdRetry != null) {
            gdRetry.setColor(Color.TRANSPARENT);
            gdRetry.setStroke(dp(2), Color.parseColor("#FF4D4D"));
            btnRetry.setTextColor(Color.parseColor("#FF4D4D"));
        }
    }

    private void updateLangButtonsStyle() {
        GradientDrawable gdEng = (GradientDrawable) btnEnglish.getBackground();
        GradientDrawable gdVn = (GradientDrawable) btnVietnamese.getBackground();

        if (!isVietnamese) {
            if (gdEng != null) {
                gdEng.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                gdEng.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
                gdEng.setStroke(0, Color.TRANSPARENT);
                btnEnglish.setTextColor(Color.WHITE);
            }
            if (gdVn != null) {
                gdVn.setColor(Color.TRANSPARENT);
                gdVn.setStroke(dp(2), Color.parseColor("#FF4D4D"));
                btnVietnamese.setTextColor(Color.parseColor("#FF4D4D"));
            }
        } else {
            if (gdEng != null) {
                gdEng.setColor(Color.TRANSPARENT);
                gdEng.setStroke(dp(2), Color.parseColor("#FF4D4D"));
                btnEnglish.setTextColor(Color.parseColor("#FF4D4D"));
            }
            if (gdVn != null) {
                gdVn.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                gdVn.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
                gdVn.setStroke(0, Color.TRANSPARENT);
                btnVietnamese.setTextColor(Color.WHITE);
            }
        }
    }

    private void sendFloatingButtonVisibility(String buttonType, boolean visible) {
        Intent intent = new Intent("FLOATING_BUTTON_VISIBILITY");
        intent.putExtra("button_type", buttonType);
        intent.putExtra("visible", visible);
        sendBroadcast(intent);
    }

    private void sendModeIntent(String extra, boolean enabled) {
        Intent intent = new Intent(ACTION_STATE);
        intent.putExtra(extra, enabled);
        sendBroadcast(intent);
    }

    private void checkPermissions() {
        vpnGranted = VpnService.prepare(this) == null;
        overlayGranted = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        if (Build.VERSION.SDK_INT >= 33) {
            notifGranted = checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == 0;
        } else {
            notifGranted = true;
        }
    }

    private void updatePermissionCheckboxes() {
        if (chkPermVPN != null) chkPermVPN.setChecked(vpnGranted);
        if (chkPermFloating != null) chkPermFloating.setChecked(overlayGranted);
        if (chkPermNotification != null) chkPermNotification.setChecked(notifGranted);
    }

    private void checkVpnPermission() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, REQ_VPN);
        } else {
            vpnGranted = true;
            updatePermissionCheckboxes();
        }
    }

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION), REQ_OVERLAY);
        } else {
            overlayGranted = true;
            updatePermissionCheckboxes();
        }
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
        } else {
            notifGranted = true;
            updatePermissionCheckboxes();
        }
    }

    private void updateLanguage() {
        if (isVietnamese) {
            tvTitle.setText("Psycho Developer // Fox Ping Lag");
            tvStatus.setText("TRẠNG THÁI VPN: TẮT");
            tvStats.setText("TẮT | LOSS: 0% | PING: 0ms");
            tvServerStatus.setText("Máy chủ: OK ✓");
            tvApp.setText("Chưa chọn game");
            btnEngine.setText("BẬT ENGINE");
            btnFFNormal.setText("FF NORMAL");
            btnFFMax.setText("FF MAX");
            btnRetry.setText("THỬ LẠI");
            btnStopEngine.setText("■ TẮT ENGINE");
            btnVpnOff.setText("VPN TẮT");
            btnEnglish.setText("ENGLISH");
            btnVietnamese.setText("TIẾNG VIỆT");
            tvHD.setText("HƯỚNG DẪN:");
            tvStep.setText(
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "📌 CÁCH DÙNG:\n" +
                "1️⃣ Chọn game (FF NORMAL / FF MAX / chọn khác)\n" +
                "2️⃣ Bấm BẬT ENGINE → cấp quyền VPN\n" +
                "3️⃣ Vào game, bắt đầu trận\n" +
                "4️⃣ Xong trận bấm TẮT ENGINE để tắt\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "🔞 CẢNH BÁO:\n" +
                "Dcm Mấy Thằng Lồn Change Name Cận Thận.\n" +
                "Dcm Chúng Mày Free Đừng Đòi Hỏi AntiBand.\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "⚡ Upgraded By Fox Mod.\n" +
                "🔥 Upgraded By Psycho Developer.\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            );
        } else {
            tvTitle.setText("Psycho Developer // Fox Ping Lag");
            tvStatus.setText("VPN STATUS: OFF");
            tvStats.setText("OFF | LOSS: 0% | PING: 0ms");
            tvServerStatus.setText("Server: OK ✓");
            tvApp.setText("No app selected");
            btnEngine.setText("START ENGINE");
            btnFFNormal.setText("FF NORMAL");
            btnFFMax.setText("FF MAX");
            btnRetry.setText("RETRY");
            btnStopEngine.setText("■ STOP ENGINE");
            btnVpnOff.setText("VPN OFF");
            btnEnglish.setText("ENGLISH");
            btnVietnamese.setText("TIẾNG VIỆT");
            tvHD.setText("INSTRUCTIONS:");
            tvStep.setText(
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "📌 HOW TO USE:\n" +
                "1️⃣ Select Game (FF NORMAL / FF MAX / other)\n" +
                "2️⃣ Press START ENGINE → Grant VPN permission\n" +
                "3️⃣ Enter game, start match\n" +
                "4️⃣ After match press STOP ENGINE to turn off\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "🔞 WARNING:\n" +
                "Motherfucker change name be careful.\n" +
                "You're using free tool, don't ask for anti-ban.\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                "⚡ Upgraded By Fox Mod.\n" +
                "🔥 Upgraded By Psycho Developer.\n" +
                "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            );
        }
        // Chỉ update màu (không sửa text)
        tvStatus.setTextColor(engOn ? Color.parseColor("#4DFF9E") : Color.parseColor("#FF4D4D"));
    }

    private void showFoxOverlay() {
		if (isOverlayShowing) return;
		if (overlayTextView != null) {
			try { windowManager.removeView(overlayTextView); } catch (Exception e) {}
			overlayTextView = null;
		}

		overlayTextView = new TextView(this);
		overlayTextView.setText("⚡ PSYCHO x FOX ⚡");
		overlayTextView.setTextColor(Color.WHITE);
		overlayTextView.setTextSize(10);
		overlayTextView.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
		overlayTextView.setShadowLayer(4f, 0f, 2f, Color.parseColor("#FF4D4D"));
		overlayTextView.setLetterSpacing(0.08f);
		overlayTextView.setPadding(dp(12), dp(5), dp(12), dp(5));

		// Gradient 3 màu + stroke viền sáng
		GradientDrawable overlayBg = new GradientDrawable();
		overlayBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
		overlayBg.setColors(new int[]{
								Color.parseColor("#FF4D4D"),
								Color.parseColor("#FF8C42"),
								Color.parseColor("#FF4D4D")
							});
		overlayBg.setAlpha(245);
		overlayBg.setCornerRadius(dp(16));
		overlayBg.setStroke(dp(1), Color.parseColor("#FFFFFF80"));
		overlayTextView.setBackground(overlayBg);

		// Elevation nhẹ
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			overlayTextView.setElevation(12f);
		}

		WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 
            WindowManager.LayoutParams.TYPE_PHONE,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | 
			WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
			PixelFormat.TRANSLUCENT);

		params.gravity = Gravity.BOTTOM | Gravity.START;
		params.x = dp(7);
		params.y = dp(4);

		try {
			windowManager.addView(overlayTextView, params);
			isOverlayShowing = true;

			// Animation mượt khi xuất hiện
			overlayTextView.setAlpha(0f);
			overlayTextView.setScaleX(0.85f);
			overlayTextView.setScaleY(0.85f);
			overlayTextView.animate()
				.alpha(1f)
				.scaleX(1f)
				.scaleY(1f)
				.setDuration(400)
				.setInterpolator(new android.view.animation.OvershootInterpolator())
				.start();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void hideFoxOverlay() {
		if (overlayTextView != null && overlayTextView.getParent() != null) {
			try {
				overlayTextView.animate()
					.alpha(0f)
					.scaleX(0.9f)
					.scaleY(0.9f)
					.setDuration(250)
					.withEndAction(new Runnable() {
						@Override
						public void run() {
							try {
								if (overlayTextView != null && overlayTextView.getParent() != null) {
									windowManager.removeView(overlayTextView);
								}
							} catch (Exception e) {}
							overlayTextView = null;
						}
					})
					.start();
			} catch (Exception e) {
				try {
					if (overlayTextView != null && overlayTextView.getParent() != null) {
						windowManager.removeView(overlayTextView);
					}
				} catch (Exception ex) {}
				overlayTextView = null;
			}
		}
		isOverlayShowing = false;
	}
    

    private void selectGame(String pkg, String name) {
        selPkg = pkg;
        MyVpnService1.targetPackage = pkg;
        tvApp.setText("Selected: " + name);
        toast("Selected " + name);
    }

    private Button createSimpleButton(String text, String borderColor, String bgColor, String textColor, int width, int height) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.parseColor(textColor));
        btn.setTextSize(14);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setAllCaps(false);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(bgColor));
        if (borderColor != null) gd.setStroke(dp(2), Color.parseColor(borderColor));
        gd.setCornerRadius(dp(24));
        btn.setBackground(gd);
        btn.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return btn;
    }

    private Button createStopButton(String text, String borderColor, String bgColor, String textColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.parseColor(textColor));
        btn.setTextSize(16);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setAllCaps(false);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#1A1A1A"));
        gd.setStroke(dp(1), Color.parseColor("#FF4D4D"));
        gd.setCornerRadius(dp(30));
        btn.setBackground(gd);
        return btn;
    }

    private void addSeekBarGroup(LinearLayout parent, String label, int min, int max, int defaultVal) {
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.HORIZONTAL);
        group.setGravity(Gravity.CENTER_VERTICAL);
        group.setPadding(0, dp(6), 0, dp(6));
        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#FF8C42"));
        lbl.setTextSize(13);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        lbl.setWidth(dp(70));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(defaultVal - min);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView val = new TextView(this);
        val.setText(String.valueOf(defaultVal));
        val.setTextColor(Color.parseColor("#FF8C42"));
        val.setTextSize(14);
        val.setTypeface(Typeface.MONOSPACE);
        val.setWidth(dp(50));
        val.setGravity(Gravity.END);
        val.setPadding(dp(8), dp(2), dp(8), dp(2));
        GradientDrawable valBg = new GradientDrawable();
        valBg.setColor(Color.parseColor("#1E1E1E"));
        valBg.setCornerRadius(dp(8));
        val.setBackground(valBg);
        final int minVal = min;
        final TextView textVal = val;
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					int value = progress + minVal;
					textVal.setText(String.valueOf(value));
				}
				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});
        group.addView(lbl);
        group.addView(sb);
        group.addView(val);
        parent.addView(group);
        switch (label) {
            case "VPN": sbVpn = sb; tvVpnVal = val; break;
            case "GHOST": sbGhost = sb; tvGhostVal = val; break;
            case "FREEZE": sbFreeze = sb; tvFreezeVal = val; break;
            case "TELE": sbTele = sb; tvTeleVal = val; break;
            case "Freeze2": sbFreeze2 = sb; tvFreeze2Val = val; break;
            case "Tele2": sbTele2 = sb; tvTele2Val = val; break;
        }
        // Neon progress premium
        try {
            sb.getProgressDrawable().setColorFilter(Color.parseColor("#FF4D4D"), android.graphics.PorterDuff.Mode.SRC_IN);
        } catch (Exception ignored) {}
    }

    private int dp(float val) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (val * density + 0.5f);
    }

    private void addTo(LinearLayout p, View v, int w, int h, int ml, int mt, int mr, int mb) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(ml, mt, mr, mb);
        p.addView(v, lp);
    }

    private void setUI(boolean on) {
        engOn = on;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(30));
        if (on) {
            // Primary gradient
            gd.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            gd.setColors(new int[]{Color.parseColor("#FF4D4D"), Color.parseColor("#FF8C42")});
            btnEngine.setBackground(gd);
            btnEngine.setTextColor(Color.WHITE);
            btnEngine.setText(isVietnamese ? "TẮT ENGINE" : "STOP ENGINE");
            tvStatus.setText(isVietnamese ? "TRẠNG THÁI VPN: ĐANG BẬT" : "VPN STATUS: ACTIVE");
            tvStatus.setTextColor(Color.parseColor("#4DFF9E"));
        } else {
            // Danger style
            gd.setColor(Color.parseColor("#1A1A1A"));
            gd.setStroke(dp(1), Color.parseColor("#FF4D4D"));
            btnEngine.setBackground(gd);
            btnEngine.setTextColor(Color.WHITE);
            btnEngine.setText(isVietnamese ? "BẬT ENGINE" : "START ENGINE");
            tvStatus.setText(isVietnamese ? "TRẠNG THÁI VPN: TẮT" : "VPN STATUS: OFF");
            tvStatus.setTextColor(Color.parseColor("#FF4D4D"));
        }
    }

    private void regStats() {
        statsRcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (i == null || tvStats == null) return;
                if (ACTION_STATE.equals(i.getAction())) {
                    final boolean running = i.getBooleanExtra(EXTRA_RUNNING, false);
                    runOnUiThread(new Runnable() {
							@Override
							public void run() {
								String status = running ? (isVietnamese ? "ĐANG CHẠY" : "ACTIVE") : (isVietnamese ? "TẮT" : "OFF");
								tvStats.setText(status + " | LOSS: 0% | PING: 0ms");
								tvStats.setTextColor(running ? Color.parseColor("#4DFF9E") : Color.parseColor("#CCCCCC"));
							}
						});
                }
            }
        };
        try {
            registerReceiver(statsRcv, new IntentFilter(ACTION_STATE));
        } catch (Exception e) {}
    }

    private void loadApps() {
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						PackageManager pm = getPackageManager();
						List<PackageInfo> pkgs = pm.getInstalledPackages(PackageManager.GET_META_DATA);
						final List<ApplicationInfo> res = new ArrayList<>();
						final List<String> lbs = new ArrayList<>();
						String me = getPackageName();
						for (PackageInfo pi : pkgs) {
							if (pi == null || pi.applicationInfo == null) continue;
							if (pi.packageName.equals(me)) continue;
							if (pm.getLaunchIntentForPackage(pi.packageName) == null) continue;
							String lb;
							try { lb = pm.getApplicationLabel(pi.applicationInfo).toString(); }
							catch (Exception e) { lb = pi.packageName; }
							res.add(pi.applicationInfo);
							lbs.add(lb);
						}
						final String[] arr = new String[lbs.size()];
						for (int i = 0; i < lbs.size(); i++) arr[i] = lbs.get(i);
						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									appList = res;
									appNames = arr;
									loaded = true;
								}
							});
					} catch (Exception e) { e.printStackTrace(); }
				}
			}, "LoadApps").start();
    }

    private void checkOverlay() {
        waiting = true;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try { startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION), REQ_OVERLAY); }
            catch (Exception e) { checkVpn(); }
        } else { checkVpn(); }
    }

    private void checkVpn() {
        try {
            Intent p = VpnService.prepare(this);
            if (p != null) startActivityForResult(p, REQ_VPN);
            else startEngine();
        } catch (Exception e) {
            waiting = false;
            setUI(false);
            toast("VPN Error: " + e.getMessage());
        }
    }

    private void startEngine() {
        waiting = false;
        try {
            MyVpnService1.targetPackage = selPkg;
            Intent vi = new Intent(this, MyVpnService1.class);
            vi.setAction(ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(vi);
            else startService(vi);
            btnEngine.postDelayed(new Runnable() {
					@Override
					public void run() {
						try {
							Intent fi = new Intent(MainActivity.this, FloatingControlService.class);
							if (Build.VERSION.SDK_INT >= 26) startForegroundService(fi);
							else startService(fi);
							showFoxOverlay();
						} catch (Exception e) {}
					}
				}, 500);
            setUI(true);
            toast(isVietnamese ? "ENGINE ĐÃ BẬT!" : "Engine ON!");
        } catch (Exception e) {
            waiting = false;
            setUI(false);
            toast("Error: " + e.getMessage());
        }
    }

    private void stopEngine() {
        waiting = false;
        try {
            stopService(new Intent(this, FloatingControlService.class));
            Intent vi = new Intent(this, MyVpnService1.class);
            vi.setAction(ACTION_STOP);
            startService(vi);
            setUI(false);
            toast(isVietnamese ? "ENGINE ĐÃ TẮT!" : "Engine OFF!");
            hideFoxOverlay();
        } catch (Exception e) {}
    }

    private void showPicker() {
        if (appList.isEmpty()) { toast(isVietnamese ? "Không tìm thấy ứng dụng!" : "No apps found!"); return; }
        try {
            new AlertDialog.Builder(this)
                .setTitle(isVietnamese ? "CHỌN GAME" : "SELECT GAME")
                .setItems(appNames, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int i) {
                        ApplicationInfo ai = appList.get(i);
                        selPkg = ai.packageName;
                        MyVpnService1.targetPackage = selPkg;
                        tvApp.setText((isVietnamese ? "Đã chọn: " : "Selected: ") + appNames[i]);
                        toast((isVietnamese ? "Đã chọn: " : "Selected: ") + appNames[i]);
                    }
                })
                .setNegativeButton(isVietnamese ? "Hủy" : "Cancel", null).show();
        } catch (Exception e) {}
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            overlayGranted = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
            updatePermissionCheckboxes();
            checkVpn();
        } else if (req == REQ_VPN) {
            vpnGranted = VpnService.prepare(this) == null;
            updatePermissionCheckboxes();
            if (res == RESULT_OK) startEngine();
            else { waiting = false; setUI(false); toast(isVietnamese ? "Cần cấp quyền VPN!" : "VPN permission required!"); }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATION) {
            notifGranted = grantResults.length > 0 && grantResults[0] == 0;
            updatePermissionCheckboxes();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (statsRcv != null) unregisterReceiver(statsRcv); } catch (Exception e) {}
        try { hideFoxOverlay(); } catch (Exception e) {}
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
				}
			});
    }
}
