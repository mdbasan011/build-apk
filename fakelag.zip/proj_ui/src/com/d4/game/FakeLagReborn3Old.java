package com.d4.game;

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FakeLagReborn3Old extends Service {

    public static final String ACTION_FLOAT_VISIBILITY = "com.fakelag.reborn.FLOAT_VISIBILITY";
    public static final String ACTION_VPN_CHANGED = "com.fakelag.reborn.VPN_STATE_CHANGED";
    public static final String EXTRA_VPN_ON = "vpn_on";

    private static final String CHANNEL_ID = "fn_floating";
    private static final String PREFS = "FakeNinjaPrefs";
    private static final String KEY_FLOAT_FREEZE = "float_show_freeze";
    private static final String KEY_FLOAT_GHOST = "float_show_ghost";
    private static final String KEY_FLOAT_VPN = "float_show_vpn";

    // Button positions
    public static int posXFreeze = 100;
    public static int posYFreeze = 300;
    public static int posXNinja = 100;
    public static int posYNinja = 500;
    public static int posXVpn = 100;
    public static int posYVpn = 700;

    // Button sizes
    public static int szFreeze = 70;
    public static int szNinja = 70;
    public static int szVpn = 70;

    private WindowManager windowManager;
    private TextView btnFreeze;
    private TextView btnGhost;
    private TextView btnVpn;

    private boolean stateFreeze = false;
    private boolean stateGhost = false;
    private boolean stateVpn = false;
    private int btnSizeDp = 70;

    private SharedPreferences prefs;
    private Handler handler = new Handler();

    private BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.hasExtra(EXTRA_VPN_ON)) {
                boolean vpnOn = intent.getBooleanExtra(EXTRA_VPN_ON, false);
                updateVpnState(vpnOn);
            }
        }
    };

    private BroadcastReceiver floatVisibilityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                boolean showFreeze = intent.getBooleanExtra(KEY_FLOAT_FREEZE, true);
                boolean showGhost = intent.getBooleanExtra(KEY_FLOAT_GHOST, true);
                boolean showVpn = intent.getBooleanExtra(KEY_FLOAT_VPN, true);
                applyButtonVisibility(showFreeze, showGhost, showVpn);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        loadPositions();
        createFloatingButtons();
        startNotification();

        registerReceiver(vpnReceiver, new android.content.IntentFilter(ACTION_VPN_CHANGED));
        registerReceiver(floatVisibilityReceiver, new android.content.IntentFilter(ACTION_FLOAT_VISIBILITY));
    }

    private void loadPositions() {
        posXFreeze = prefs.getInt("posXFreeze", posXFreeze);
        posYFreeze = prefs.getInt("posYFreeze", posYFreeze);
        posXNinja = prefs.getInt("posXNinja", posXNinja);
        posYNinja = prefs.getInt("posYNinja", posYNinja);
        posXVpn = prefs.getInt("posXVpn", posXVpn);
        posYVpn = prefs.getInt("posYVpn", posYVpn);

        szFreeze = prefs.getInt("szFreeze", szFreeze);
        szNinja = prefs.getInt("szNinja", szNinja);
        szVpn = prefs.getInt("szVpn", szVpn);
    }

    private void savePositions() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("posXFreeze", posXFreeze);
        editor.putInt("posYFreeze", posYFreeze);
        editor.putInt("posXNinja", posXNinja);
        editor.putInt("posYNinja", posYNinja);
        editor.putInt("posXVpn", posXVpn);
        editor.putInt("posYVpn", posYVpn);
        editor.putInt("szFreeze", szFreeze);
        editor.putInt("szNinja", szNinja);
        editor.putInt("szVpn", szVpn);
        editor.apply();
    }

    private void createFloatingButtons() {
        btnFreeze = createButton("FREEZE", posXFreeze, posYFreeze, szFreeze);
        btnGhost = createButton("GHOST", posXNinja, posYNinja, szNinja);
        btnVpn = createButton("VPN", posXVpn, posYVpn, szVpn);
    }

    private TextView createButton(String text, int x, int y, int size) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundColor(Color.parseColor("#DD000000"));
        button.setPadding(10, 10, 10, 10);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(8);
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            dpToPx(size),
            dpToPx(size),
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
			WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
			WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = x;
        params.y = y;

        // FIX: Pass params as final by using a copy or use class-level variables
        // Create listener with final copies of variables
        final TextView finalButton = button;
        final WindowManager.LayoutParams finalParams = params;
        final String finalLabel = text;

        button.setOnTouchListener(new View.OnTouchListener() {
				private int startX, startY;
				private float touchX, touchY;
				private boolean isDragging = false;
				private Handler handler = new Handler();
				private Runnable longPressRunnable = new Runnable() {
					@Override
					public void run() {
						toggleLock(finalButton, finalLabel);
					}
				};

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							startX = finalParams.x;
							startY = finalParams.y;
							touchX = event.getRawX();
							touchY = event.getRawY();
							isDragging = false;
							handler.postDelayed(longPressRunnable, 500);
							return true;

						case MotionEvent.ACTION_MOVE:
							float deltaX = event.getRawX() - touchX;
							float deltaY = event.getRawY() - touchY;
							if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
								isDragging = true;
								handler.removeCallbacks(longPressRunnable);
							}
							if (isDragging) {
								finalParams.x = startX + (int) deltaX;
								finalParams.y = startY + (int) deltaY;
								windowManager.updateViewLayout(finalButton, finalParams);
								savePosition(finalLabel, finalParams.x, finalParams.y);
							}
							return true;

						case MotionEvent.ACTION_UP:
							handler.removeCallbacks(longPressRunnable);
							if (!isDragging) {
								onClickButton(finalButton, finalLabel);
							}
							return true;
					}
					return false;
				}
			});

        windowManager.addView(button, params);
        return button;
    }

    private void toggleLock(TextView btn, String label) {
        pulseButton(btn);
    }

    private void onClickButton(TextView btn, String label) {
        pulseButton(btn);
        switch (label) {
            case "FREEZE":
                stateFreeze = !stateFreeze;
                updateButtonStyle(btn, stateFreeze);
                break;
            case "GHOST":
                stateGhost = !stateGhost;
                updateButtonStyle(btn, stateGhost);
                break;
            case "VPN":
                stateVpn = !stateVpn;
                updateButtonStyle(btn, stateVpn);
                sendToVpn(stateVpn ? "connect" : "disconnect");
                break;
        }
    }

    private void savePosition(String label, int x, int y) {
        switch (label) {
            case "FREEZE":
                posXFreeze = x;
                posYFreeze = y;
                break;
            case "GHOST":
                posXNinja = x;
                posYNinja = y;
                break;
            case "VPN":
                posXVpn = x;
                posYVpn = y;
                break;
        }
        savePositions();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void startNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(
                CHANNEL_ID,
                "Floating Menu",
                android.app.NotificationManager.IMPORTANCE_LOW
            );
            android.app.NotificationManager manager = getSystemService(android.app.NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }

            android.app.Notification notification = new android.app.Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("RAIKU // THUNDER_PAIN")
                .setContentText("Floating menu active")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .build();
            startForeground(1, notification);
        }
    }

    private void applyButtonVisibility(boolean showFreeze, boolean showGhost, boolean showVpn) {
        if (btnFreeze != null) {
            btnFreeze.setVisibility(showFreeze ? View.VISIBLE : View.GONE);
        }
        if (btnGhost != null) {
            btnGhost.setVisibility(showGhost ? View.VISIBLE : View.GONE);
        }
        if (btnVpn != null) {
            btnVpn.setVisibility(showVpn ? View.VISIBLE : View.GONE);
        }
    }

    private void updateVpnState(boolean isOn) {
        stateVpn = isOn;
        updateButtonStyle(btnVpn, stateVpn);
    }

    private void updateButtonStyle(TextView btn, boolean active) {
        if (btn == null) return;
        if (active) {
            btn.setBackgroundColor(Color.parseColor("#FF3366"));
        } else {
            btn.setBackgroundColor(Color.parseColor("#DD000000"));
        }
    }

    private void pulseButton(final TextView btn) {
        if (btn == null) return;
        btn.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction(new Runnable() {
                @Override
                public void run() {
                    btn.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                }
            })
            .start();
    }

    private void sendToVpn(String data) {
        Intent intent = new Intent("com.fakelag.reborn.VPN_COMMAND");
        intent.putExtra("command", data);
        sendBroadcast(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if (ACTION_FLOAT_VISIBILITY.equals(action)) {
                boolean showFreeze = intent.getBooleanExtra(KEY_FLOAT_FREEZE, true);
                boolean showGhost = intent.getBooleanExtra(KEY_FLOAT_GHOST, true);
                boolean showVpn = intent.getBooleanExtra(KEY_FLOAT_VPN, true);
                applyButtonVisibility(showFreeze, showGhost, showVpn);
            } else if (ACTION_VPN_CHANGED.equals(action)) {
                boolean vpnOn = intent.getBooleanExtra(EXTRA_VPN_ON, false);
                updateVpnState(vpnOn);
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(vpnReceiver);
            unregisterReceiver(floatVisibilityReceiver);
        } catch (IllegalArgumentException e) {
            // Receiver already unregistered
        }

        if (btnFreeze != null && windowManager != null) {
            try {
                windowManager.removeView(btnFreeze);
                windowManager.removeView(btnGhost);
                windowManager.removeView(btnVpn);
            } catch (Exception e) {
                // View already removed
            }
        }

        savePositions();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */
