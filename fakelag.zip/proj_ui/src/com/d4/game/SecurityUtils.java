package com.d4.game;

import android.os.Build;
import android.os.Debug;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class SecurityUtils {

    public static boolean isCompromised() {
        return isRooted() || isEmulator() || isDebuggerAttached() || isHookPresent();
    }

    // ---- Root ----
    public static boolean isRooted() {
        String[] suPaths = {"/system/bin/su","/system/xbin/su","/sbin/su",
            "/data/local/xbin/su","/data/local/bin/su","/data/local/su",
            "/system/sd/xbin/su","/system/bin/failsafe/su"};
        for (String p : suPaths) if (new File(p).exists()) return true;

        String[] magiskPaths = {"/sbin/.magisk","/sbin/.core/mirror","/data/adb/magisk","/data/adb/modules"};
        for (String p : magiskPaths) if (new File(p).exists()) return true;

        String tags = Build.TAGS;
        if (tags != null && tags.contains("test-keys")) return true;
        return false;
    }

    // ---- Emulator ----
    public static boolean isEmulator() {
        boolean byBuild = Build.FINGERPRINT.startsWith("generic")
            || Build.FINGERPRINT.startsWith("unknown")
            || Build.MODEL.contains("google_sdk")
            || Build.MODEL.contains("Emulator")
            || Build.MODEL.contains("Android SDK built for x86")
            || Build.MODEL.contains("Genymotion")
            || Build.MANUFACTURER.contains("Genymotion")
            || Build.BRAND.startsWith("generic")
            || Build.DEVICE.startsWith("generic")
            || Build.HARDWARE.contains("goldfish")
            || Build.HARDWARE.contains("ranchu")
            || Build.PRODUCT.contains("sdk")
            || Build.PRODUCT.contains("vbox86p");
        if (byBuild) return true;

        String[] emuFiles = {"/dev/socket/qemud","/dev/qemu_pipe","/system/lib/libc_malloc_debug_qemu.so"};
        for (String f : emuFiles) if (new File(f).exists()) return true;

        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop","ro.kernel.qemu"});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String val = br.readLine(); br.close();
            if ("1".equals(val != null ? val.trim() : "")) return true;
        } catch (Exception ignored) {}
        return false;
    }

    // ---- Debugger ----
    public static boolean isDebuggerAttached() {
        return Debug.isDebuggerConnected() || Debug.waitingForDebugger();
    }

    // ---- Hook (Xposed / Frida) ----
    public static boolean isHookPresent() {
        // Xposed class check
        try { Class.forName("de.robv.android.xposed.XposedBridge"); return true; }
        catch (ClassNotFoundException ignored) {}

        // Xposed files
        String[] xFiles = {"/system/framework/XposedBridge.jar","/system/lib/libxposed_art.so"};
        for (String f : xFiles) if (new File(f).exists()) return true;

        // Xposed stack trace
        try { throw new Exception(); }
        catch (Exception e) {
            for (StackTraceElement el : e.getStackTrace())
                if (el.getClassName().contains("de.robv.android.xposed")) return true;
        }

        // Frida port 27042
        try {
            java.net.Socket s = new java.net.Socket();
            s.connect(new java.net.InetSocketAddress("127.0.0.1", 27042), 100);
            s.close(); return true;
        } catch (Exception ignored) {}

        // Frida files
        String[] fridaFiles = {"/data/local/tmp/frida-server","/data/local/tmp/re.frida.server"};
        for (String f : fridaFiles) if (new File(f).exists()) return true;

        return false;
    }
}
