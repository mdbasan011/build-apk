package com.d4.game;

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class FakeLagReborn4 {

    private static final String MSG = 
	"\n📱 TikTok: @takashistore777official\n" +
	"🎥 YouTube: @Dongkys\n" +
	"💬 Telegram: t.me/fakelagreborn\n" +
	"🌐 Website: fakelag.nekoweb.org\n\n" +
	"⚡ Psycho Developer: RAIKU // THUNDER_PAIN";

    private static final LinkInfo[] LINKS = {
        new LinkInfo("TikTok: @takashistore777official", "https://tiktok.com/@takashistore777official"),
        new LinkInfo("YouTube: @Dongkys", "https://youtube.com/@Dongkys"),
        new LinkInfo("Telegram: t.me/fakelagreborn", "https://t.me/fakelagreborn"),
        new LinkInfo("Website: fakelag.nekoweb.org", "https://fakelag.nekoweb.org")
    };

    public static void show(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("⚡ RAIKU // THUNDER_PAIN");

        final SpannableString spannable = new SpannableString(MSG);

        // Xử lý từng link
        for (int i = 0; i < LINKS.length; i++) {
            final LinkInfo link = LINKS[i];
            final String text = link.text;
            final String url = link.url;

            final int start = spannable.toString().indexOf(text);
            if (start >= 0) {
                final int end = start + text.length();

                spannable.setSpan(new ClickableSpan() {
						@Override
						public void onClick(View widget) {
							openUrl(context, url);
						}

						@Override
						public void updateDrawState(TextPaint ds) {
							super.updateDrawState(ds);
							ds.setColor(0xFF00FF9D);
							ds.setUnderlineText(true);
						}
					}, start, end, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        final TextView textView = new TextView(context);
        textView.setText(spannable);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setPadding(40, 30, 40, 30);
        textView.setTextSize(14);
        textView.setTextColor(0xFFCCCCCC);

        builder.setView(textView);

        builder.setPositiveButton("ĐÓNG", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

        builder.setNegativeButton("SHARE", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					shareApp(context);
				}
			});

        builder.show();
    }

    private static void openUrl(Context context, String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "Không mở được link", Toast.LENGTH_SHORT).show();
        }
    }

    private static void shareApp(Context context) {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, 
								 "🔥 RAIKU // THUNDER_PAIN - Game Booster VIP\n" +
								 "Download: https://fakelag.nekoweb.org\n" +
								 "Telegram: https://t.me/fakelagreborn\n" +
								 "⚡ Psycho Developer: RAIKU");
            Intent chooser = Intent.createChooser(shareIntent, "Share via");
            chooser.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) {
            Toast.makeText(context, "Không thể share", Toast.LENGTH_SHORT).show();
        }
    }

    private static class LinkInfo {
        String text;
        String url;
        LinkInfo(String text, String url) {
            this.text = text;
            this.url = url;
        }
    }
}

/**
 * Psycho Developer: RAIKU // THUNDER_PAIN
 */
