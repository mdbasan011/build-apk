package com.d4.game;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class MyVpnService1 extends VpnService {
    private static final long MODE_TIMEOUT_MS = 30000;
    private static final String NOTIF_CH = "V1";
    private static final int TLK_ANCHOR_MS = 3000;
    private static final int TLK_HB_MAX = 49;
    private static final int TLK_MOVE_MAX = 300;
    private static final int TLK_MOVE_MIN = 30;
    private static final int GHOST_DELAY_MIN = 10;
    private static final int GHOST_DELAY_MAX = 25;
    private static final int FREEZE_DELAY_MIN = 5;
    private static final int FREEZE_DELAY_MAX = 15;
    private static final int MOVE_MIN = 55;
    private static final int MOVE_MAX = 125;
    private static final int KEEPALIVE_MAX = 54;
    private static final int SAFE_PACKET_SIZE = 50;

    // Game ports (Free Fire)
    private static final int GAME_PORT_START = 10000;
    private static final int GAME_PORT_END = 10030;
    private static final int GAME_PORT_FF = 27015;

    private ExecutorService threadPool;
    private ScheduledExecutorService scheduler;
    private FileOutputStream tunOut;
    private ParcelFileDescriptor vpnInterface;

    public static final String ACTION_STATE = "com.d4.game.VPN_STATE";
    public static final String EXTRA_RUNNING = "running";
    public static final String EXTRA_FREEZE = "freeze";
    public static final String EXTRA_GHOST = "ghost";
    public static final String EXTRA_TLK = "tlk";
    public static final String EXTRA_TELEKILL = "telekill";
    public static final String EXTRA_TELEPORTV2 = "teleportv2";
    public static final String EXTRA_NGUNG = "ngung";
    public static final String EXTRA_GHOSTKILL = "ghostkill";
    public static final String EXTRA_INTERCEPT = "intercept";

    public static final String ACTION_FREEZE = "com.example.gamebooster.FREEZE";
    public static final String ACTION_GHOST = "com.example.gamebooster.GHOST";
    public static final String ACTION_TLK = "com.example.gamebooster.TLK";
    public static final String ACTION_TELEKILL = "com.example.gamebooster.TELEKILL";
    public static final String ACTION_TELEPORTV2 = "com.example.gamebooster.TELEPORTV2";
    public static final String ACTION_NGUNG = "com.example.gamebooster.NGUNG";
    public static final String ACTION_GHOSTKILL = "com.example.gamebooster.GHOSTKILL";
    public static final String ACTION_STOP = "com.d4.game.STOP";
    public static final String ACTION_START = "com.d4.game.START";

    private static final byte[] E_SL = {12, 10, 20, 119, 22, 21, 21, 10};

    public static volatile boolean isFreeze = false;
    public static volatile boolean isNgung = false;
    public static volatile boolean isGhost = false;
    public static volatile boolean isGhostKill = false;
    public static volatile boolean isTlk = false;
    public static volatile boolean isTeleKill = false;
    public static volatile boolean isTeleportV2 = false;
    public static volatile boolean isRunning = false;
    public static volatile boolean isIntercept = true;
    public static volatile String targetPackage = "";
    static final Random rnd = new Random();
    private static final String[] NTITLES = {"Google Play Services", "Android System", "Connectivity Service", "Background Sync", "Device Health", "Firebase Services", "System Health Monitor", "Carrier Services"};
    private volatile long freezeStartMs = 0;
    private final CopyOnWriteArrayList<byte[]> freezeBuffer = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<byte[]> ghostBuffer = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<byte[]> gkBuffer = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<byte[]> teleKillBuffer = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<byte[]> teleportV2Buffer = new CopyOnWriteArrayList<>();
    private ScheduledFuture<?> teleKillReplayFuture;
    private ScheduledFuture<?> teleportV2ReplayFuture;
    private final ConcurrentHashMap<ConnectionKey, DatagramSocket> udpMap = new ConcurrentHashMap<>();
    private int nIdx = 0;

    static String x(byte[] bArr) {
        byte[] bArr2 = new byte[bArr.length];
        for (int i = 0; i < bArr.length; i++) {
            bArr2[i] = (byte) (bArr[i] ^ 90);
        }
        try {
            return new String(bArr2, "UTF-8");
        } catch (Exception e) {
            return new String(bArr2);
        }
    }

    private void initChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(NOTIF_CH) == null) {
                NotificationChannel channel = new NotificationChannel(NOTIF_CH, "Game Booster", NotificationManager.IMPORTANCE_LOW);
                channel.setShowBadge(false);
                channel.enableLights(false);
                channel.enableVibration(false);
                channel.setSound(null, null);
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification mkNotif() {
        this.nIdx = (this.nIdx + 1) % NTITLES.length;
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, NOTIF_CH);
        } else {
            builder = new Notification.Builder(this);
        }
        return builder.setContentTitle(NTITLES[this.nIdx])
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setPriority(Notification.PRIORITY_LOW)
            .setOngoing(true)
            .build();
    }

    static class ConnectionKey {
        final int srcIp, srcPort, dstIp, dstPort;
        ConnectionKey(int srcIp, int srcPort, int dstIp, int dstPort) {
            this.srcIp = srcIp; this.srcPort = srcPort; this.dstIp = dstIp; this.dstPort = dstPort;
        }
        @Override
        public boolean equals(Object obj) {
            if (obj instanceof ConnectionKey) {
                ConnectionKey o = (ConnectionKey) obj;
                return srcIp == o.srcIp && srcPort == o.srcPort && dstIp == o.dstIp && dstPort == o.dstPort;
            }
            return false;
        }
        @Override
        public int hashCode() {
            return ((((srcIp * 31) + srcPort) * 31) + dstIp) * 31 + dstPort;
        }
    }

    static class Packet {
        int srcIp, dstIp, srcPort, dstPort, len, plOff, plLen;
        byte[] raw;
        Packet(byte[] data, int length) throws Exception {
            this.raw = new byte[length];
            this.len = length;
            System.arraycopy(data, 0, this.raw, 0, length);
            int ipHeaderLen = (data[0] & 0x0F) * 4;
            this.srcIp = ((data[12] & 0xFF) << 24) | ((data[13] & 0xFF) << 16) | ((data[14] & 0xFF) << 8) | (data[15] & 0xFF);
            this.dstIp = ((data[16] & 0xFF) << 24) | ((data[17] & 0xFF) << 16) | ((data[18] & 0xFF) << 8) | (data[19] & 0xFF);
            if (length > ipHeaderLen + 8) {
                this.srcPort = ((data[ipHeaderLen] & 0xFF) << 8) | (data[ipHeaderLen + 1] & 0xFF);
                this.dstPort = ((data[ipHeaderLen + 2] & 0xFF) << 8) | (data[ipHeaderLen + 3] & 0xFF);
                int udpLen = ((data[ipHeaderLen + 4] & 0xFF) << 8) | (data[ipHeaderLen + 5] & 0xFF);
                this.plOff = ipHeaderLen + 8;
                this.plLen = Math.max(0, udpLen - 8);
                if (this.plOff + this.plLen > length) this.plLen = length - this.plOff;
            }
        }

        boolean isMovement() {
            return plLen >= MOVE_MIN && plLen <= MOVE_MAX;
        }

        boolean isFromClient() {
            return srcPort > 1024 && (dstPort == GAME_PORT_FF || (dstPort >= GAME_PORT_START && dstPort <= GAME_PORT_END));
        }

        boolean isFromServer() {
            return (srcPort == GAME_PORT_FF || (srcPort >= GAME_PORT_START && srcPort <= GAME_PORT_END)) && dstPort > 1024;
        }

        void corruptPayload() {
            if (plLen > 10 && raw != null && plOff + 8 < raw.length) {
                // XOR mạnh để làm sai lệch vị trí
                for (int i = 0; i < 8 && i < plLen; i++) {
                    raw[plOff + i] = (byte) (raw[plOff + i] ^ 0xFF);
                }
            }
        }
    }

    class UdpListenerThread extends Thread {
        final ConnectionKey key;
        final DatagramSocket sock;
        UdpListenerThread(DatagramSocket sock, ConnectionKey key) {
            this.sock = sock; this.key = key; setDaemon(true);
        }
        @Override
        public void run() {
            byte[] buffer = new byte[65536];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            while (isRunning && !sock.isClosed()) {
                try {
                    sock.receive(packet);
                    int len = packet.getLength();
                    if (!isFreeze || len <= 20 || isTeleKill || isTeleportV2) {
                        if (!isNgung || len < TLK_MOVE_MIN || len > TLK_MOVE_MAX) {
                            if (!isIntercept || len <= 20 || len <= 40 || len < 44 || len > 85) {
                                byte[] reply = buildReply(key.dstIp, packet.getPort(), key.srcIp, key.srcPort, packet.getData(), len);
                                if (tunOut != null) {
                                    synchronized (tunOut) { tunOut.write(reply); }
                                }
                            }
                        }
                    }
                } catch (Exception e) { return; }
            }
        }
    }

    class FreezeFlush extends Thread {
        FreezeFlush() { setDaemon(true); }
        @Override
        public void run() {
            Object[] arr = freezeBuffer.toArray();
            freezeBuffer.clear();
            for (Object obj : arr) {
                try { sendOut(new Packet((byte[]) obj, ((byte[]) obj).length)); } catch (Exception e) {}
            }
        }
    }

    class WatchThread extends Thread {
        WatchThread() { setDaemon(true); }
        @Override
        public void run() {
            while (isRunning) {
                try {
                    Thread.sleep(1000);
                    if (!isRunning) return;
                    long now = System.currentTimeMillis();
                    if (isFreeze && freezeStartMs > 0 && now - freezeStartMs > MODE_TIMEOUT_MS) {
                        isFreeze = false;
                        freezeStartMs = 0;
                        new FreezeFlush().start();
                        sendState();
                    }
                } catch (Exception e) { return; }
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initChannel();
        if (threadPool == null || threadPool.isShutdown()) {
            threadPool = Executors.newCachedThreadPool();
        }
        if (scheduler == null || scheduler.isShutdown()) {
            scheduler = Executors.newSingleThreadScheduledExecutor();
        }
    }

    private void startTeleKillReplay() {
        if (teleKillReplayFuture != null) teleKillReplayFuture.cancel(false);
        teleKillReplayFuture = scheduler.scheduleAtFixedRate(new Runnable() {
				@Override
				public void run() {
					if (!isTeleKill || !isRunning) return;
					if (teleKillBuffer.isEmpty()) return;
					// Replay toàn bộ buffer mỗi 300ms → giật liên tục
					for (byte[] data : teleKillBuffer) {
						try {
							sendOut(new Packet(data, data.length));
						} catch (Exception e) {}
					}
				}
			}, 300, 300, TimeUnit.MILLISECONDS);
    }

    private void stopTeleKillReplay() {
        if (teleKillReplayFuture != null) {
            teleKillReplayFuture.cancel(false);
            teleKillReplayFuture = null;
        }
    }

    private void startTeleportV2Replay() {
        if (teleportV2ReplayFuture != null) teleportV2ReplayFuture.cancel(false);
        teleportV2ReplayFuture = scheduler.scheduleAtFixedRate(new Runnable() {
				@Override
				public void run() {
					if (!isTeleportV2 || !isRunning) return;
					if (teleportV2Buffer.isEmpty()) return;
					// Replay buffer + corrupt để enemy giật mạnh
					for (byte[] data : teleportV2Buffer) {
						try {
							Packet p = new Packet(data, data.length);
							p.corruptPayload();
							sendOut(p);
						} catch (Exception e) {}
					}
				}
			}, 250, 250, TimeUnit.MILLISECONDS);
    }

    private void stopTeleportV2Replay() {
        if (teleportV2ReplayFuture != null) {
            teleportV2ReplayFuture.cancel(false);
            teleportV2ReplayFuture = null;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (threadPool == null || threadPool.isShutdown()) {
            threadPool = Executors.newCachedThreadPool();
        }
        if (scheduler == null || scheduler.isShutdown()) {
            scheduler = Executors.newSingleThreadScheduledExecutor();
        }
        try { startForeground(1, mkNotif()); } catch (Exception e) {}

        String action = (intent == null || intent.getAction() == null) ? "" : intent.getAction();

        if (ACTION_START.equals(action)) {
            new Thread(new Runnable() {
					@Override
					public void run() { startEngine(); }
				}).start();
        } else if (ACTION_FREEZE.equals(action)) {
            isFreeze = !isFreeze;
            if (isFreeze) {
                freezeStartMs = System.currentTimeMillis();
            } else {
                freezeStartMs = 0;
                new FreezeFlush().start();
            }
            sendState();
        } else if (ACTION_NGUNG.equals(action)) {
            isNgung = !isNgung;
            sendState();
        } else if (ACTION_GHOST.equals(action)) {
            isGhost = !isGhost;
            sendState();
        } else if (ACTION_GHOSTKILL.equals(action)) {
            isGhostKill = !isGhostKill;
            sendState();
        } else if (ACTION_TELEKILL.equals(action)) {
            isTeleKill = !isTeleKill;
            if (isTeleKill) {
                startTeleKillReplay();
            } else {
                stopTeleKillReplay();
                teleKillBuffer.clear();
            }
            sendState();
        } else if (ACTION_TELEPORTV2.equals(action)) {
            isTeleportV2 = !isTeleportV2;
            if (isTeleportV2) {
                startTeleportV2Replay();
            } else {
                stopTeleportV2Replay();
                teleportV2Buffer.clear();
            }
            sendState();
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
            new Handler(Looper.getMainLooper()).post(new Runnable() {
					@Override
					public void run() { stopSelf(); }
				});
        } else {
            new Thread(new Runnable() {
					@Override
					public void run() { startEngine(); }
				}).start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopAll();
        super.onDestroy();
    }

    private void startEngine() {
        if (!isRunning) {
            try {
                Builder builder = new Builder();
                builder.setSession("Game Booster")
                    .setMtu(1500)
                    .addAddress("10.0.0.2", 32)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("8.8.8.8")
                    .addDnsServer("1.1.1.1");

                if (!targetPackage.isEmpty()) {
                    try { builder.addAllowedApplication(targetPackage); }
                    catch (Exception e) {
                        try { builder.addDisallowedApplication(getPackageName()); }
                        catch (Exception e2) {}
                    }
                } else {
                    try { builder.addDisallowedApplication(getPackageName()); }
                    catch (Exception e) {}
                }

                vpnInterface = builder.establish();
                if (vpnInterface == null) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
							@Override
							public void run() { stopSelf(); }
						});
                } else {
                    isRunning = true;
                    isIntercept = false;
                    freezeBuffer.clear();
                    ghostBuffer.clear();
                    gkBuffer.clear();
                    teleKillBuffer.clear();
                    teleportV2Buffer.clear();
                    closeAll();
                    tunOut = new FileOutputStream(vpnInterface.getFileDescriptor());
                    new Thread(new Runnable() {
							@Override
							public void run() {
								loop(new FileInputStream(vpnInterface.getFileDescriptor()));
							}
						}, x(E_SL)).start();
                    new WatchThread().start();
                    sendState();
                }
            } catch (Exception e) {
                isRunning = false;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
						@Override
						public void run() { stopSelf(); }
					});
            }
        }
    }

    private void stopAll() {
        if (isFreeze) {
            isFreeze = false;
            Object[] arr = freezeBuffer.toArray();
            freezeBuffer.clear();
            for (Object obj : arr) {
                try { sendOut(new Packet((byte[]) obj, ((byte[]) obj).length)); } catch (Exception e) {}
            }
        }
        if (isTlk) { isTlk = false; }
        if (isTeleKill) { 
            isTeleKill = false;
            stopTeleKillReplay();
            teleKillBuffer.clear();
        }
        if (isTeleportV2) { 
            isTeleportV2 = false;
            stopTeleportV2Replay();
            teleportV2Buffer.clear();
        }
        if (isGhostKill) { isGhostKill = false; gkBuffer.clear(); }
        if (isGhost) { isGhost = false; ghostBuffer.clear(); }
        isNgung = false;
        isIntercept = false;
        isRunning = false;
        closeAll();
        if (threadPool != null) { threadPool.shutdownNow(); threadPool = null; }
        if (scheduler != null) { scheduler.shutdownNow(); scheduler = null; }
        try { if (tunOut != null) { tunOut.close(); tunOut = null; } } catch (Exception e) {}
        try { if (vpnInterface != null) { vpnInterface.close(); vpnInterface = null; } } catch (Exception e) {}
        sendState();
    }

    private void closeAll() {
        for (DatagramSocket sock : udpMap.values()) {
            try { sock.close(); } catch (Exception e) {}
        }
        udpMap.clear();
    }

    private boolean isMovementPacket(int plLen) {
        return plLen >= MOVE_MIN && plLen <= MOVE_MAX;
    }

    private boolean isKeepAlivePacket(int plLen) {
        return plLen >= 38 && plLen <= KEEPALIVE_MAX;
    }

    private void loop(FileInputStream in) {
        byte[] buffer = new byte[65536];
        while (isRunning) {
            try {
                int len = in.read(buffer);
                if (len > 0) {
                    byte[] data = new byte[len];
                    System.arraycopy(buffer, 0, data, 0, len);
                    if (len < 20 || (data[9] & 0xFF) != 17) {
                        if (tunOut != null) {
                            synchronized (tunOut) { tunOut.write(data, 0, len); }
                        }
                    } else {
                        try {
                            Packet pkt = new Packet(data, len);
                            if (pkt.plLen <= 0) {
                                if (tunOut != null) {
                                    synchronized (tunOut) { tunOut.write(data, 0, len); }
                                }
                            } else {
                                if (pkt.plLen <= SAFE_PACKET_SIZE) {
                                    sendOut(pkt);
                                    continue;
                                }
                                if (isKeepAlivePacket(pkt.plLen)) {
                                    sendOut(pkt);
                                    continue;
                                }
                                boolean isMove = isMovementPacket(pkt.plLen);

                                if (isFreeze) {
                                    if (isMove) {
                                        int delay = FREEZE_DELAY_MIN + rnd.nextInt(FREEZE_DELAY_MAX - FREEZE_DELAY_MIN);
                                        try { Thread.sleep(delay); } catch (Exception e) {}
                                    }
                                    sendOut(pkt);
                                } 
                                else if (isGhost) {
                                    if (isMove) {
                                        int delay = GHOST_DELAY_MIN + rnd.nextInt(GHOST_DELAY_MAX - GHOST_DELAY_MIN);
                                        try { Thread.sleep(delay); } catch (Exception e) {}
                                        if (pkt.plLen > 10 && pkt.raw != null && pkt.plOff + 5 < pkt.raw.length) {
                                            pkt.raw[pkt.plOff + 5] = (byte) (pkt.raw[pkt.plOff + 5] ^ 0x01);
                                        }
                                    }
                                    sendOut(pkt);
                                } 
                                else if (isTeleKill) {
                                    // TELEKILL: Lưu buffer + replay liên tục
                                    if (pkt.isFromClient() && isMove) {
                                        teleKillBuffer.add(pkt.raw.clone());
                                        if (teleKillBuffer.size() > 100) teleKillBuffer.remove(0);
                                        // KHÔNG DROP - vẫn gửi để duy trì kết nối
                                    }
                                    sendOut(pkt);
                                } 
                                else if (isTeleportV2) {
                                    // TELEPORT V2: Lưu buffer + replay + corrupt payload
                                    if (pkt.isFromServer() && isMove) {
                                        teleportV2Buffer.add(pkt.raw.clone());
                                        if (teleportV2Buffer.size() > 100) teleportV2Buffer.remove(0);
                                        // Corrupt payload để enemy giật
                                        pkt.corruptPayload();
                                    }
                                    sendOut(pkt);
                                }
                                else if (isGhostKill) {
                                    if (isMove && rnd.nextInt(100) < 15) {
                                        continue;
                                    }
                                    sendOut(pkt);
                                } 
                                else {
                                    sendOut(pkt);
                                }
                            }
                        } catch (Exception e) {}
                    }
                }
            } catch (Exception e) {}
        }
    }

    private void sendOut(Packet pkt) {
        try {
            ConnectionKey key = new ConnectionKey(pkt.srcIp, pkt.srcPort, pkt.dstIp, pkt.dstPort);
            DatagramSocket sock = udpMap.get(key);
            if (sock == null || sock.isClosed()) {
                if (udpMap.size() > 64) {
                    Iterator<Map.Entry<ConnectionKey, DatagramSocket>> it = udpMap.entrySet().iterator();
                    while (it.hasNext()) {
                        if (it.next().getValue().isClosed()) it.remove();
                    }
                }
                sock = new DatagramSocket();
                protect(sock);
                udpMap.put(key, sock);
                new UdpListenerThread(sock, key).start();
            }
            if (pkt.plLen > 0) {
                byte[] payload = new byte[pkt.plLen];
                System.arraycopy(pkt.raw, pkt.plOff, payload, 0, pkt.plLen);
                sock.send(new DatagramPacket(payload, payload.length,
											 InetAddress.getByAddress(new byte[]{(byte) (pkt.dstIp >> 24), (byte) (pkt.dstIp >> 16), (byte) (pkt.dstIp >> 8), (byte) pkt.dstIp}),
											 pkt.dstPort));
            }
        } catch (Exception e) {}
    }

    private byte[] buildReply(int srcIp, int srcPort, int dstIp, int dstPort, byte[] data, int len) {
        int totalLen = 28 + len;
        byte[] packet = new byte[totalLen];
        packet[0] = 0x45;
        packet[1] = 0x00;
        packet[2] = (byte) (totalLen >> 8);
        packet[3] = (byte) totalLen;
        packet[4] = 0x00;
        packet[5] = 0x00;
        packet[6] = 0x40;
        packet[8] = 0x40;
        packet[9] = 0x11;
        writeInt(packet, 12, srcIp);
        writeInt(packet, 16, dstIp);
        int sum = 0;
        for (int i = 0; i < 20; i += 2) {
            sum += ((packet[i] & 0xFF) << 8) | (packet[i + 1] & 0xFF);
        }
        while ((sum >> 16) != 0) {
            sum = (sum & 0xFFFF) + (sum >> 16);
        }
        int checksum = ~sum & 0xFFFF;
        packet[10] = (byte) (checksum >> 8);
        packet[11] = (byte) checksum;
        packet[20] = (byte) (srcPort >> 8);
        packet[21] = (byte) srcPort;
        packet[22] = (byte) (dstPort >> 8);
        packet[23] = (byte) dstPort;
        int udpLen = 8 + len;
        packet[24] = (byte) (udpLen >> 8);
        packet[25] = (byte) udpLen;
        System.arraycopy(data, 0, packet, 28, len);
        return packet;
    }

    private void writeInt(byte[] packet, int offset, int value) {
        packet[offset] = (byte) (value >> 24);
        packet[offset + 1] = (byte) (value >> 16);
        packet[offset + 2] = (byte) (value >> 8);
        packet[offset + 3] = (byte) value;
    }

    private void sendState() {
        try {
            Intent intent = new Intent(ACTION_STATE);
            intent.putExtra(EXTRA_RUNNING, isRunning);
            intent.putExtra(EXTRA_FREEZE, isFreeze);
            intent.putExtra(EXTRA_GHOST, isGhost);
            intent.putExtra(EXTRA_TLK, isTlk);
            intent.putExtra(EXTRA_TELEKILL, isTeleKill);
            intent.putExtra(EXTRA_TELEPORTV2, isTeleportV2);
            intent.putExtra(EXTRA_NGUNG, isNgung);
            intent.putExtra(EXTRA_GHOSTKILL, isGhostKill);
            intent.putExtra(EXTRA_INTERCEPT, isIntercept);
            sendBroadcast(intent);
        } catch (Exception e) {}
    }
}
