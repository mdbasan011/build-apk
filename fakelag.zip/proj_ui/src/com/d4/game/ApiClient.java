package com.d4.game;

import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;

public class ApiClient {

    // ============================================================
    // ⚠️ THAY ĐỔI CÁC GIÁ TRỊ NÀY
    // ============================================================
    static final String API_BASE   = "https://servervip.x10.mx/serveradminkey/api";  // ← URL server PHP của bạn
    static final String HMAC_SECRET = "ManhDungDepTraiNhatTheGioi"; // ← giống config.php
    static final String GET_KEY_URL = "https://servervip.x10.mx/getkey"; // ← link mua key
    // ============================================================

    private static final String TAG     = "D4_API";
    private static final int    TIMEOUT = 10000;

    // ---- Verify key ----
    public static VerifyResult verifyKey(String key, String deviceId) {
        try {
            JSONObject body = new JSONObject();
            body.put("key", key);
            body.put("device_id", deviceId);
            String resp = post(API_BASE + "/verify.php", body.toString());
            if (resp == null) return VerifyResult.fail("network_error");
            JSONObject json = new JSONObject(resp);
            if (!json.optBoolean("success", false))
                return VerifyResult.fail(json.optString("error", "unknown"));
            return VerifyResult.ok(json.optString("token"), json.optString("expires_at"));
        } catch (Exception e) {
            Log.e(TAG, "verifyKey error", e);
            return VerifyResult.fail("exception");
        }
    }

    private static String post(String urlStr, String jsonBody) {
        HttpsURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setConnectTimeout(TIMEOUT);
            conn.setReadTimeout(TIMEOUT);
            conn.setDoOutput(true);
            byte[] bytes = jsonBody.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }

            int code = conn.getResponseCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            String responseBody = sb.toString();

            // Verify HMAC signature để chống fake response
            String timestamp = conn.getHeaderField("X-Timestamp");
            String signature  = conn.getHeaderField("X-Signature");
            if (timestamp != null && signature != null) {
                if (!verifyHmac(responseBody, timestamp, signature)) {
                    Log.e(TAG, "HMAC mismatch - possible fake response!");
                    return null;
                }
            }
            return responseBody;
        } catch (Exception e) {
            Log.e(TAG, "POST error", e);
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static boolean verifyHmac(String body, String timestamp, String sig) {
        try {
            long ts = Long.parseLong(timestamp);
            if (Math.abs(System.currentTimeMillis() / 1000L - ts) > 120) return false;
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new javax.crypto.spec.SecretKeySpec(
                HMAC_SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] hash = mac.doFinal((body + timestamp).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return hex.toString().equals(sig);
        } catch (Exception e) { return false; }
    }

    // ---- Result ----
    public static class VerifyResult {
        public final boolean success;
        public final String token, expiresAt, error;
        private VerifyResult(boolean s, String t, String e2, String err) {
            success = s; token = t; expiresAt = e2; error = err;
        }
        static VerifyResult ok(String t, String e)  { return new VerifyResult(true,  t, e, null); }
        static VerifyResult fail(String err)         { return new VerifyResult(false, null, null, err); }
    }
}
