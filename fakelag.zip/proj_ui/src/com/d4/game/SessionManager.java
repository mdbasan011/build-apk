package com.d4.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

public class SessionManager {

    private static final String PREF_NAME  = "d4_prefs";
    private static final String KEY_TOKEN  = "s_tok";
    private static final String KEY_EXP    = "s_exp";
    private static final String KEY_DEVID  = "s_dev";

    private final SharedPreferences prefs;

    public SessionManager(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveSession(String token, String expiresAt) {
        prefs.edit().putString(KEY_TOKEN, token).putString(KEY_EXP, expiresAt).apply();
    }

    public boolean hasValidSession() {
        String token = prefs.getString(KEY_TOKEN, null);
        if (token == null || token.isEmpty()) return false;
        String exp = prefs.getString(KEY_EXP, null);
        if (exp != null) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date d = sdf.parse(exp);
                if (d != null && d.before(new Date())) return false;
            } catch (Exception ignored) {}
        }
        return true;
    }

    public void clearSession() {
        prefs.edit().remove(KEY_TOKEN).remove(KEY_EXP).apply();
    }

    public String getDeviceId(Context ctx) {
        String cached = prefs.getString(KEY_DEVID, null);
        if (cached != null && !cached.isEmpty()) return cached;
        String androidId = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
        String deviceId;
        if (androidId != null && !androidId.isEmpty() && !androidId.equals("9774d56d682e549c")) {
            deviceId = sha256(androidId).substring(0, 32);
        } else {
            deviceId = UUID.randomUUID().toString().replace("-", "").substring(0, 32);
        }
        prefs.edit().putString(KEY_DEVID, deviceId).apply();
        return deviceId;
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return input; }
    }
}
