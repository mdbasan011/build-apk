package com.d4.game;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class FloatingControlService extends Service {

    private static final int NID = 2;
    private static final String NCH = "gb";
    private static final String PREFS_NAME = "OverlayPrefs";

    private static final String ACTION_START = "com.d4.game.START";
    private static final String ACTION_STOP = "com.d4.game.STOP";
    private static final String ACTION_FREEZE = "com.example.gamebooster.FREEZE";
    private static final String ACTION_GHOST = "com.example.gamebooster.GHOST";
    private static final String ACTION_TELEKILL = "com.example.gamebooster.TELEKILL";
    private static final String ACTION_TELEPORTV2 = "com.example.gamebooster.TELEPORTV2";
    private static final String ACTION_STATE = "com.d4.game.VPN_STATE";
    private static final String EXTRA_RUNNING = "running";
    private static final String EXTRA_FREEZE = "freeze";
    private static final String EXTRA_GHOST = "ghost";
    private static final String EXTRA_TELEKILL = "telekill";
    private static final String EXTRA_TELEPORTV2 = "teleportv2";

    private WindowManager wm;
    private Map<String, TextView> buttons = new HashMap<>();
    private Map<String, Boolean> buttonLocked = new HashMap<>();
    private Map<String, Boolean> buttonVisibility = new HashMap<>();

    private TextView btnVpn, btnFreeze, btnGhost, btnTeleKill, btnTeleportV2, stat;
    private boolean onVpn = false, onFreeze = false, onGhost = false, onTeleKill = false, onTeleportV2 = false;
    private boolean addV = false, addF = false, addG = false, addTK = false, addTV2 = false, addStat = false;
    private BroadcastReceiver stateReceiver;
    private BroadcastReceiver sizeReceiver;
    private BroadcastReceiver visibilityReceiver;
    private SharedPreferences prefs;
    private Handler mainHandler;

    private MediaPlayer mpOn, mpOff;
    private boolean soundReady = false;

    private WindowManager.LayoutParams vpnParams, freezeParams, ghostParams, teleKillParams, teleportV2Params;
    private int vpnSize = 130, freezeSize = 130, ghostSize = 130, teleKillSize = 130, teleportV2Size = 130;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        mainHandler = new Handler(Looper.getMainLooper());

        vpnSize = prefs.getInt("vpn_size", 130);
        freezeSize = prefs.getInt("freeze_size", 130);
        ghostSize = prefs.getInt("ghost_size", 130);
        teleKillSize = prefs.getInt("telekill_size", 130);
        teleportV2Size = prefs.getInt("teleportv2_size", 130);

        initSound();

        startForegroundService();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        int vpnX = prefs.getInt("vpn_x", 20);
        int vpnY = prefs.getInt("vpn_y", 80);
        int freezeX = prefs.getInt("freeze_x", 20);
        int freezeY = prefs.getInt("freeze_y", 240);
        int ghostX = prefs.getInt("ghost_x", 20);
        int ghostY = prefs.getInt("ghost_y", 400);
        int tkX = prefs.getInt("telekill_x", 20);
        int tkY = prefs.getInt("telekill_y", 560);
        int tv2X = prefs.getInt("teleportv2_x", 20);
        int tv2Y = prefs.getInt("teleportv2_y", 720);
        int statX = prefs.getInt("stat_x", 12);
        int statY = prefs.getInt("stat_y", 60);

        btnVpn = createButton("VPN OFF", vpnX, vpnY, 0, vpnSize);
        btnFreeze = createButton("FREEZE", freezeX, freezeY, 1, freezeSize);
        btnGhost = createButton("GHOST", ghostX, ghostY, 2, ghostSize);
        btnTeleKill = createButton("TELEKILL", tkX, tkY, 3, teleKillSize);
        btnTeleportV2 = createButton("TELEPORT V2", tv2X, tv2Y, 4, teleportV2Size);

        buttons.put("VPN", btnVpn);
        buttons.put("FREEZE", btnFreeze);
        buttons.put("GHOST", btnGhost);
        buttons.put("TELEKILL", btnTeleKill);
        buttons.put("TELEPORTV2", btnTeleportV2);

        for (String key : buttons.keySet()) {
            boolean locked = prefs.getBoolean("locked_" + key, false);
            buttonLocked.put(key, locked);
            if (locked && buttons.get(key) != null) {
                buttons.get(key).setAlpha(0.5f);
            }
        }

        createStatusBar(statX, statY);
        registerReceivers();

        updateButtonAppearance(btnVpn, "VPN", false);
        updateButtonAppearance(btnFreeze, "FREEZE", false);
        updateButtonAppearance(btnGhost, "GHOST", false);
        updateButtonAppearance(btnTeleKill, "TELEKILL", false);
        updateButtonAppearance(btnTeleportV2, "TELEPORT V2", false);

        for (String key : buttons.keySet()) {
            boolean visible = prefs.getBoolean("visible_" + key, true);
            buttonVisibility.put(key, visible);
            if (!visible && buttons.get(key) != null) {
                try { wm.removeView(buttons.get(key)); } catch (Exception e) {}
            }
        }
    }

    private void initSound() {
        try {
            // Load file turnon (nếu có)
            try {
                mpOn = MediaPlayer.create(this, R.raw.turnon);
                if (mpOn != null) mpOn.setVolume(1.0f, 1.0f);
            } catch (Exception e) {
                mpOn = null;
            }

            // Load file turnoff (nếu có)
            try {
                mpOff = MediaPlayer.create(this, R.raw.turnoff);
                if (mpOff != null) mpOff.setVolume(1.0f, 1.0f);
            } catch (Exception e) {
                mpOff = null;
            }

            soundReady = (mpOn != null || mpOff != null);

        } catch (Exception e) {
            soundReady = false;
        }
    }

    private void playSound(boolean isTurningOn) {
        if (!soundReady) return;
        try {
            MediaPlayer mp = isTurningOn ? mpOn : mpOff;
            if (mp != null) {
                if (mp.isPlaying()) {
                    mp.pause();
                    mp.seekTo(0);
                }
                mp.start();
            }
        } catch (Exception e) {}
    }

    private void startForegroundService() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(NCH, "Game Booster", NotificationManager.IMPORTANCE_LOW);
                ch.setSound(null, null);
                if (nm != null) nm.createNotificationChannel(ch);
            }
            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= 26) {
                builder = new Notification.Builder(this, NCH);
            } else {
                builder = new Notification.Builder(this);
            }
            builder.setContentTitle("Game Booster")
				.setContentText("Floating Controls Active")
				.setSmallIcon(android.R.drawable.ic_menu_compass);
            startForeground(NID, builder.build());
        } catch (Exception e) {}
    }

    private TextView createButton(final String text, int x, int y, final int id, int size) {
        try {
            final TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(Math.max(8, size / 13f));
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setGravity(Gravity.CENTER);
            tv.setSingleLine(true);
            tv.setPadding(0, 0, 0, 0);

            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(Color.parseColor("#1F2A3A"));
            bg.setStroke(2, Color.parseColor("#FFB74D"));
            tv.setBackground(bg);

            int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

            final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                size, size, windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = x;
            params.y = y;
            wm.addView(tv, params);

            if (id == 0) { vpnParams = params; addV = true; }
            else if (id == 1) { freezeParams = params; addF = true; }
            else if (id == 2) { ghostParams = params; addG = true; }
            else if (id == 3) { teleKillParams = params; addTK = true; }
            else if (id == 4) { teleportV2Params = params; addTV2 = true; }

            final String buttonKey = getButtonKey(id);

            tv.setOnTouchListener(new View.OnTouchListener() {
					int startX, startY;
					float startRawX, startRawY;
					boolean isDragging;
					long downTime;

					@Override
					public boolean onTouch(View v, MotionEvent e) {
						int action = e.getAction();
						if (action == MotionEvent.ACTION_DOWN) {
							downTime = System.currentTimeMillis();
							startX = params.x;
							startY = params.y;
							startRawX = e.getRawX();
							startRawY = e.getRawY();
							isDragging = false;
							return true;
						}
						if (action == MotionEvent.ACTION_MOVE) {
							float dx = e.getRawX() - startRawX;
							float dy = e.getRawY() - startRawY;
							if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
								isDragging = true;
								if (!buttonLocked.getOrDefault(buttonKey, false)) {
									params.x = startX + (int) dx;
									params.y = startY + (int) dy;
									try { wm.updateViewLayout(tv, params); } catch (Exception ex) {}
								}
							}
							return true;
						}
						if (action == MotionEvent.ACTION_UP) {
							long duration = System.currentTimeMillis() - downTime;
							if (!isDragging && duration >= 5000) {
								toggleLock(buttonKey, tv);
								return true;
							}
							if (!isDragging && duration < 500) {
								onButtonTap(id);
							} else if (isDragging) {
								savePosition(id, params.x, params.y);
							}
							return true;
						}
						return false;
					}
				});
            return tv;
        } catch (Exception e) {
            return null;
        }
    }

    private String getButtonKey(int id) {
        switch (id) {
            case 0: return "VPN";
            case 1: return "FREEZE";
            case 2: return "GHOST";
            case 3: return "TELEKILL";
            case 4: return "TELEPORTV2";
            default: return "";
        }
    }

    private void toggleLock(String buttonKey, TextView tv) {
        boolean currentLock = buttonLocked.getOrDefault(buttonKey, false);
        boolean newLock = !currentLock;
        buttonLocked.put(buttonKey, newLock);
        prefs.edit().putBoolean("locked_" + buttonKey, newLock).apply();

        if (newLock) {
            tv.setAlpha(0.5f);
            showToast(buttonKey + " 🔒 ĐÃ KHÓA - Nhấn giữ 5s để mở");
        } else {
            tv.setAlpha(1f);
            showToast(buttonKey + " 🔓 ĐÃ MỞ KHÓA");
        }
    }

    private void onButtonTap(int id) {
        Intent intent = new Intent(this, MyVpnService1.class);

        if (id == 0) {
            onVpn = !onVpn;
            updateButtonAppearance(btnVpn, "VPN", onVpn);
            intent.setAction(onVpn ? ACTION_START : ACTION_STOP);
            startService(intent);
            animateButton(btnVpn);
        } 
        else if (id == 1) {
            boolean wasOn = onFreeze;
            onFreeze = !onFreeze;
            updateButtonAppearance(btnFreeze, "FREEZE", onFreeze);
            intent.setAction(ACTION_FREEZE);
            startService(intent);
            animateButton(btnFreeze);
            if (onFreeze && !onVpn) autoStartVpn();
            playSound(!wasOn);
        } 
        else if (id == 2) {
            boolean wasOn = onGhost;
            onGhost = !onGhost;
            updateButtonAppearance(btnGhost, "GHOST", onGhost);
            intent.setAction(ACTION_GHOST);
            startService(intent);
            animateButton(btnGhost);
            if (onGhost && !onVpn) autoStartVpn();
            playSound(!wasOn);
        } 
        else if (id == 3) {
            boolean wasOn = onTeleKill;
            onTeleKill = !onTeleKill;
            updateButtonAppearance(btnTeleKill, "TELEKILL", onTeleKill);
            intent.setAction(ACTION_TELEKILL);
            startService(intent);
            animateButton(btnTeleKill);
            if (onTeleKill && !onVpn) autoStartVpn();
            if (onTeleKill && stat != null) stat.setText("⚡ TELEKILL ON");
            playSound(!wasOn);
        } 
        else if (id == 4) {
            boolean wasOn = onTeleportV2;
            onTeleportV2 = !onTeleportV2;
            updateButtonAppearance(btnTeleportV2, "TELEPORT V2", onTeleportV2);
            intent.setAction(ACTION_TELEPORTV2);
            startService(intent);
            animateButton(btnTeleportV2);
            if (onTeleportV2 && !onVpn) autoStartVpn();
            if (onTeleportV2 && stat != null) stat.setText("🌀 TELEPORT V2 ON");
            playSound(!wasOn);
        }
    }

    private void autoStartVpn() {
        onVpn = true;
        updateButtonAppearance(btnVpn, "VPN", true);
        Intent vpnIntent = new Intent(this, MyVpnService1.class);
        vpnIntent.setAction(ACTION_START);
        startService(vpnIntent);
    }

    private void animateButton(final TextView tv) {
        if (tv == null) return;
        tv.animate().scaleX(1.2f).scaleY(1.2f).setDuration(100)
			.withEndAction(new Runnable() {
				@Override
				public void run() {
					if (tv != null) {
						tv.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					}
				}
			}).start();
    }

    private void createStatusBar(int startX, int startY) {
        try {
            stat = new TextView(this);
            stat.setText("VPN OFF");
            stat.setTextSize(11);
            stat.setTypeface(Typeface.MONOSPACE);
            stat.setPadding(12, 10, 12, 10);
            stat.setTextColor(Color.parseColor("#FFB74D"));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#DD1A1F2E"));
            bg.setCornerRadius(16);
            bg.setStroke(1, Color.parseColor("#FFB74D"));
            stat.setBackground(bg);

            int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

            final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                windowType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.RIGHT;
            params.x = startX;
            params.y = startY;
            wm.addView(stat, params);
            addStat = true;

            stat.setOnTouchListener(new View.OnTouchListener() {
					int lastX, lastY;
					float startRawX, startRawY;

					@Override
					public boolean onTouch(View v, MotionEvent e) {
						int action = e.getAction();
						if (action == MotionEvent.ACTION_DOWN) {
							lastX = params.x;
							lastY = params.y;
							startRawX = e.getRawX();
							startRawY = e.getRawY();
							return true;
						}
						if (action == MotionEvent.ACTION_MOVE) {
							params.x = lastX + (int) (e.getRawX() - startRawX);
							params.y = lastY + (int) (e.getRawY() - startRawY);
							try { wm.updateViewLayout(stat, params); } catch (Exception ex) {}
							return true;
						}
						if (action == MotionEvent.ACTION_UP) {
							prefs.edit().putInt("stat_x", params.x).putInt("stat_y", params.y).apply();
							return true;
						}
						return false;
					}
				});
        } catch (Exception e) {}
    }

    private void registerReceivers() {
        stateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (i == null || stat == null || !addStat) return;
                if (!ACTION_STATE.equals(i.getAction())) return;

                boolean running = i.getBooleanExtra(EXTRA_RUNNING, false);
                boolean freeze = i.getBooleanExtra(EXTRA_FREEZE, false);
                boolean ghost = i.getBooleanExtra(EXTRA_GHOST, false);
                boolean teleKill = i.getBooleanExtra(EXTRA_TELEKILL, false);
                boolean teleportV2 = i.getBooleanExtra(EXTRA_TELEPORTV2, false);

                if (freeze != onFreeze) {
                    onFreeze = freeze;
                    updateButtonAppearance(btnFreeze, "FREEZE", onFreeze);
                }
                if (ghost != onGhost) {
                    onGhost = ghost;
                    updateButtonAppearance(btnGhost, "GHOST", onGhost);
                }
                if (teleKill != onTeleKill) {
                    onTeleKill = teleKill;
                    updateButtonAppearance(btnTeleKill, "TELEKILL", onTeleKill);
                }
                if (teleportV2 != onTeleportV2) {
                    onTeleportV2 = teleportV2;
                    updateButtonAppearance(btnTeleportV2, "TELEPORT V2", onTeleportV2);
                }
                if (running != onVpn) {
                    onVpn = running;
                    updateButtonAppearance(btnVpn, "VPN", onVpn);
                }

                String status = "VPN OFF";
                if (running) {
                    if (freeze) status = "❄️ FREEZE";
                    else if (ghost) status = "👻 GHOST";
                    else if (teleKill) status = "⚡ TELEKILL";
                    else if (teleportV2) status = "🌀 TELEPORT V2";
                    else status = "✅ ACTIVE";
                }
                stat.setText(status + "\n--ms L:0%");
                stat.setTextColor(Color.parseColor("#4CAF50"));
            }
        };
        registerReceiver(stateReceiver, new IntentFilter(ACTION_STATE));

        sizeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                if (!"UPDATE_BUTTON_SIZE".equals(intent.getAction())) return;

                final String buttonType = intent.getStringExtra("button_type");
                final int newSize = intent.getIntExtra("size", 130);
                if (buttonType == null) return;
                mainHandler.post(new Runnable() {
						@Override
						public void run() {
							updateButtonSize(buttonType, newSize);
						}
					});
            }
        };
        registerReceiver(sizeReceiver, new IntentFilter("UPDATE_BUTTON_SIZE"));

        visibilityReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                if (!"FLOATING_BUTTON_VISIBILITY".equals(intent.getAction())) return;

                final String buttonType = intent.getStringExtra("button_type");
                final boolean visible = intent.getBooleanExtra("visible", true);
                mainHandler.post(new Runnable() {
						@Override
						public void run() {
							setButtonVisibility(buttonType, visible);
						}
					});
            }
        };
        registerReceiver(visibilityReceiver, new IntentFilter("FLOATING_BUTTON_VISIBILITY"));
    }

    private void updateButtonSize(String buttonType, int newSize) {
        WindowManager.LayoutParams params = null;
        TextView button = null;

        if (buttonType.equals("vpn")) {
            params = vpnParams; button = btnVpn; vpnSize = newSize;
        } else if (buttonType.equals("freeze")) {
            params = freezeParams; button = btnFreeze; freezeSize = newSize;
        } else if (buttonType.equals("ghost")) {
            params = ghostParams; button = btnGhost; ghostSize = newSize;
        } else if (buttonType.equals("telekill")) {
            params = teleKillParams; button = btnTeleKill; teleKillSize = newSize;
        } else if (buttonType.equals("teleportv2")) {
            params = teleportV2Params; button = btnTeleportV2; teleportV2Size = newSize;
        } else {
            return;
        }

        if (params != null && button != null) {
            params.width = newSize;
            params.height = newSize;
            try {
                wm.updateViewLayout(button, params);
                button.setTextSize(Math.max(8, newSize / 13f));
                prefs.edit().putInt(buttonType + "_size", newSize).apply();
            } catch (Exception e) {}
        }
    }

    private void setButtonVisibility(String buttonType, boolean visible) {
        TextView btn = null;
        WindowManager.LayoutParams params = null;

        switch (buttonType) {
            case "VPN": btn = btnVpn; params = vpnParams; break;
            case "FREEZE": btn = btnFreeze; params = freezeParams; break;
            case "GHOST": btn = btnGhost; params = ghostParams; break;
            case "TELEKILL": btn = btnTeleKill; params = teleKillParams; break;
            case "TELEPORTV2": btn = btnTeleportV2; params = teleportV2Params; break;
            default: return;
        }

        if (btn == null || params == null) return;

        try {
            if (visible && btn.getParent() == null) {
                wm.addView(btn, params);
            } else if (!visible && btn.getParent() != null) {
                wm.removeView(btn);
            }
        } catch (Exception e) {}
    }

    private void updateButtonAppearance(TextView tv, String label, boolean isActive) {
        if (tv == null) return;
        try {
            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.OVAL);
            if (isActive) {
                gd.setColor(Color.parseColor("#2E7D32"));
                gd.setStroke(2, Color.parseColor("#4CAF50"));
                tv.setTextColor(Color.parseColor("#4CAF50"));
                tv.setText(label + " ON");
            } else {
                gd.setColor(Color.parseColor("#4A2C2C"));
                gd.setStroke(2, Color.parseColor("#FF8A65"));
                tv.setTextColor(Color.parseColor("#FF8A65"));
                tv.setText(label);
            }
            tv.setBackground(gd);
        } catch (Exception e) {}
    }

    private void savePosition(int id, int x, int y) {
        SharedPreferences.Editor editor = prefs.edit();
        switch (id) {
            case 0: editor.putInt("vpn_x", x); editor.putInt("vpn_y", y); break;
            case 1: editor.putInt("freeze_x", x); editor.putInt("freeze_y", y); break;
            case 2: editor.putInt("ghost_x", x); editor.putInt("ghost_y", y); break;
            case 3: editor.putInt("telekill_x", x); editor.putInt("telekill_y", y); break;
            case 4: editor.putInt("teleportv2_x", x); editor.putInt("teleportv2_y", y); break;
        }
        editor.apply();
    }

    private void showToast(final String msg) {
        mainHandler.post(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(FloatingControlService.this, msg, Toast.LENGTH_SHORT).show();
				}
			});
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mpOn != null) {
            mpOn.release();
            mpOn = null;
        }
        if (mpOff != null) {
            mpOff.release();
            mpOff = null;
        }
        try { if (stateReceiver != null) unregisterReceiver(stateReceiver); } catch (Exception e) {}
        try { if (sizeReceiver != null) unregisterReceiver(sizeReceiver); } catch (Exception e) {}
        try { if (visibilityReceiver != null) unregisterReceiver(visibilityReceiver); } catch (Exception e) {}

        removeView(btnVpn, addV);
        removeView(btnFreeze, addF);
        removeView(btnGhost, addG);
        removeView(btnTeleKill, addTK);
        removeView(btnTeleportV2, addTV2);
        removeView(stat, addStat);

        Intent intent = new Intent(this, MyVpnService1.class);
        intent.setAction(ACTION_STOP);
        startService(intent);
    }

    private void removeView(View v, boolean added) {
        if (!added || v == null) return;
        try {
            wm.removeView(v);
        } catch (Exception e) {}
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
